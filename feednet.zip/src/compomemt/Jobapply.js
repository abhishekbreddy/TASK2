import React from 'react'
import './Job.css'
 
export default class Coursepayment extends React.Component{

    // state={
    //     apiData:[]
    // }
    
    
    // 
    

    // submit=()=> {
    //     alert("ok")
    //      Axios.post("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
    //             this.setState({
    //                 data:res.data
    //             })
    //             apiData.data =res.data
    //           console.log("apidata",apiData.data)
    //      },(err)=>{
    //        alert(err)
    //      })
    // }


render(){

    return(<div className="container m-5">
    <div className="container float-right">
        <input className="form-control m-3 p-x-5 "placeholder="name"/>
    <input className="form-control m-3 p-x-5" placeholder="email"/>
    <input className="form-control m-3 p-x-5"placeholder="mobilenumber"/>
    <input className="form-control m-3 w-3"placeholder="city"/>
    <input className="form-control m-3 "placeholder="qualification"/>
    <input className="form-control m-3"placeholder="year of passing"/>
    <input className="form-control m-3"placeholder="percentage"/>
    <input className="form-control m-3"placeholder="Apply for"/>
    <input type="file" className="form-control m-3" placeholder="Resume"/>
    {/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
    
    <button type= "submit">submit</button></div></div> )} 



}