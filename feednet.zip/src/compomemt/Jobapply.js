import React, { useState } from 'react'
import './Job.css'
 
export default function Jobapply (){

    const [name,setName]=useState("")
    const [mobile,setMobile]=useState(0)
    const [email,setEmail]=useState("")
    const[qualification,setQualification]=useState("")
    const [city,setcity]=useState("")
    const [yearofpassing,setYearofpassing]=useState(0)
    const [percentage,setPercentage]=useState(0)
    const[Applyfor,setApplyfor]=useState("")
    const[Resume,setResume]=useState("")









    // state={
    //     apiData:[]
    // }
    
    
    // 
    

    // submit=()=> {
    //     alert("ok")
    //      Axios.post("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
    //             this.setState({
    //                 data:res.data
    //             })
    //             apiData.data =res.data
    //           console.log("apidata",apiData.data)
    //      },(err)=>{
    //        alert(err)
    //      })
    // }




    return(<div className="container"style={{width:"100%",float:"right",background:"linear-gradient(245deg,black,darkblue)"}}>
   <h1 style={{color:'white'}}>Apply here</h1>
    <div className="container"style={{width:"70%", float:"right" }}><form>
        
        <div className="input-group">
         <input type="text" name="name" placeholder="Name" onChange={(event)=>{setName(event.target.value)}} style={{borderBottom: "2px solid gray",width:"45%"}} />
         <input className="mt-2 ml-3" type="number"name="phno" placeholder="Email"style={{width:"50%"}} onChange={(event)=>{setEmail(event.target.value)}}/>
         </div><div className="input-group">
    <input placeholder="mobilenumber"style={{width:"45%"}}onChange={(event)=>{setMobile(event.target.value)}}/>
    <input className=" mt-2 ml-3"placeholder="city"style={{width:"50%"}}onChange={(event)=>{setcity(event.target.value)}}/></div>
    <div className="input-group">
    <input placeholder="qualification"style={{width:"97%"}}onChange={(event)=>{setQualification(event.target.value)}}/></div>
    <div className="input-group">
    <input placeholder="year of passing"style={{width:"45%"}}onChange={(event)=>{setYearofpassing(event.target.value)}}/>
    <input className=" mt-2 ml-3"placeholder="percentage"style={{width:"50%"}}onChange={(event)=>{setPercentage(event.target.value)}}/></div>
    <div className="input-group">
    <input placeholder="Apply for"style={{width:"97%"}}onChange={(event)=>{setApplyfor(event.target.value)}}/></div>
    <div className="input-group">
    <input type="file"  placeholder="Resume"style={{width:"97%",}}onChange={(event)=>{setResume(event.target.value)}}/></div>

    {/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
    
    <button type= "submit">submit</button></form></div></div> )} 



