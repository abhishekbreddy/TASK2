import React from 'react'
import Image from './pics/rd.jpg'
import Image1 from'./pics/y.png'
import Image3 from './pics/z.jpg'
import {Link} from 'react-router-dom'
import './services.css'

export default class Services extends React.Component{
    render(){
        return(<div>
           
         
           <div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item">Servces</li>
                    </ul></div>







           
           
           
           <div className="card-group">
        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> RESEARCH & DEVELOPMENT </h4>
          <p>R&D – is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell.</p>
        
          </div>
          
          
          
          
       </div>
       
       <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image1}} />
          <h4 className="card-title card-link"> PRODUCT DEVELOPMENT</h4>
          <p>Product development is a creation of new or different product that offers benefits to the end user includes both creation of an new product and modifications to an existing product</p>
        
          </div>
          
          
          
          
       </div>

       <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image3}} />
          <h4 className="card-title card-link"> AI SOLUTIONS & SERVICES </h4>
          <p>
Today Machine Learning and Artificial Intelligence is penetrating every side of the business, from deploying Chatbots to AI-driven platforms.</p>
        
          </div>
          
          
          
          
       </div></div>
       <button className="btn-primary m-5"><Link className="text-light" to="/other">other trainings</Link></button>
       
       
       
       
       
       
       
       
       </div>)
    }
}