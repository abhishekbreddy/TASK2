import React from 'react'
import {Link} from 'react-router-dom'

import './Nav.css'
export default class Navigation extends React.Component{
    render(){
        return(<div><ul className="nav justify-content-end">
        <li >
          <Link class="nav-link active"  to="/">Home</Link>
        </li>
        <li class="dropdown">
    <Link class="dropbtn nav-link">Services</Link>
    <div class="dropdown-content"><ul><li>
      <Link>R&D</Link><br/>
      <Link >PRODUCT</Link><br/>
      <Link >AI Services</Link>
      </li></ul>
    </div></li>
       <li >
       <li class="dropdown">
    <Link class="dropbtn  nav-link ">Training</Link>
    <div class="dropdown-content"><ul><li>
      <Link>Corporate</Link><br/>
      <Link >Seminars</Link><br/>
      <Link >Internships</Link><br/>
      <Link>Workshops</Link>
      </li></ul>
    </div></li>
        </li>
        <li class="dropdown">
    <Link class="dropbtn  nav-link ">Pay</Link>
    <div class="dropdown-content"><ul><li>
      <Link>Service Payment</Link><br/>
      <Link >Course Payment</Link><br/>
      
      </li></ul>
    </div></li>
    
        <li>
          <Link class="nav-link" to="/Carriers">Carriers</Link>
        </li>
        <li >
          <Link class="nav-link" to="/Blog">Blog</Link>
        </li>
        <li >
          <Link class="nav-link" to="/About">About</Link>
        </li>
      </ul>

        </div>)
    }
}