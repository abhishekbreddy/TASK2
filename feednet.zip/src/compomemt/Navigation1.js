import React from 'react'
import {Link} from 'react-router-dom'

import './Nav.css'
export default class Navigation extends React.Component{
    render(){
        return(<div className="p-3 "><ul className="nav justify-content-end navbar-expand-lg "style={{display: "-ms-inline-flexbox"}}>
        <li >
          <Link class="nav-link active text-dark navbar-brand mb-0  "  to="/">Home</Link>
        </li>
        <li class="dropdown">
    <Link class="dropbtn nav-link m-b-3 text-dark dropdown-toggle navbar-brand mb-0  ">Services</Link>
    <div class="dropdown-content"><ul><li>
      <Link to="/R&D" className="text-dark navbar-brand mb-0 ">R&D</Link><br/>
      <Link to="/product" className="text-dark navbar-brand mb-0 ">PRODUCT</Link><br/>
      <Link to="/AI" className="text-dark  navbar-brand mb-0 ">AIServices</Link><br/>
      <Link to="/Other" className="text-dark navbar-brand mb-0 ">Other Services</Link>
      </li></ul>
    </div></li>
       <li >
       <li class="dropdown">
    <Link class="dropbtn  nav-link text-dark dropdown-toggle navbar-brand mb-0 ">Training</Link>
    <div class="dropdown-content"><ul><li>
      <Link to="/corporate"className="text-dark navbar-brand mb-0 ">Corporate</Link><br/>
      <Link to="/Seminars" className="text-dark navbar-brand mb-0 ">Seminars</Link><br/>
      <Link to="/Internships"className="text-dark navbar-brand mb-0  ">Internships</Link><br/>
      <Link to="/Workshops"className="text-dark navbar-brand mb-0  ">Workshops</Link>
      </li></ul>
    </div></li>
        </li>
        <li class="dropdown">
    <Link class="dropbtn  nav-link  text-dark dropdown-toggle navbar-brand mb-0 ">Pay</Link>
    <div class="dropdown-content"><ul><li>
      <Link to ="/Servicepayment"className="text-dark navbar-brand mb-0 ">Service Payment</Link><br/>
      <Link to="/Coursepayment"className="text-dark navbar-brand mb-0 ">Course Payment</Link><br/>
      
      </li></ul>
    </div></li>
    
        <li>
          <Link class="nav-link text-dark navbar-brand mb-0 " to="/Carriers">Carriers</Link>
        </li>
        <li >
          <Link class="nav-link text-dark navbar-brand mb-0 " to="/Blog">Blog</Link>
        </li>
        <li >
          <Link class="nav-link text-dark navbar-brand mb-0 " to="/About">About</Link>
        </li>
<li   className="">
  <div className="dropdown-content">       
  <h1>ABOUT- US</h1>
  <p className="text-left">Feednet Solutions endeavours to draw in the best worldwide ability concentrated on research brilliance in deep learning and machine learning</p>
  
   <h1>OFFICE LOCATION</h1>

   <li className="fas fa-phone">  +91 8639522961
   </li>
   <li className="fas fa-mobile-alt"> 040-35543941
                        </li>
                        <li>
                            <i class="fas fa-envelope-open"></i>
                            post@feednetsolution.com
                        </li>         
                        <li>
                          <i class="fas fa-map-marker-alt"></i>
                            P no 65, Vittal Rao Nagar, Madhapur, Hyderabad, Telangana 500081
                        </li>                   





                        </div>

                        </li>
      </ul>

 





        </div>)
  }
  }