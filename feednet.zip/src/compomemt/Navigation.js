import React from 'react'
import {Link} from 'react-router-dom'

import './Nav.css'
export default class Navigation extends React.Component{
    render(){
        return(<div className="bg-secondary">
          <ul className="nav justify-content-centre">
          <li >
          <Link class="nav-link active text-dark"  to="/">Home</Link>
        </li>
      
    <li >
          <Link class="nav-link text-dark" to="/Services">Services</Link>
        </li> 


    <li >
          <Link class="nav-link text-dark" to="/Training">Training</Link>
        </li>
        <li >
          <Link class="nav-link text-dark" to="/Adagency">Ad Agency</Link>
        </li>  
        <li>
          <Link class="nav-link text-dark" to="/Overseas">Overseas</Link>
        </li>
        <li >
          <Link class="nav-link text-dark" to="/Contact">Contact</Link>
        </li>
        
        </ul>
        </div>
        
        
  
  




        
      
        
    )
    }
}