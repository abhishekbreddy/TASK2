import React from 'react'
import {Link} from 'react-router-dom'

import './Nav.css'
export default class Navigation extends React.Component{
    render(){
        return(<div style={{backgroundColor:"#002147"}}>
          <ul className="nav" style={{display:"inline-flex" ,width:"100%"}}>
          <li >
          <Link class="nav-link active text-light navbar-brand mb-0 HST"  to="/">Home</Link>
        </li>
      
    <li >
          <Link class="nav-link text-light navbar-brand mb-0 " to="/Services">Services</Link>
        </li> 


    <li >
          <Link class="nav-link text-light navbar-brand mb-1 " to="/Training">Training</Link>
        </li>
        <li >
          <Link class="nav-link text-light navbar-brand mb-1 " to="/Adagency">Ad Agency</Link>
        </li>  
        <li>
          <Link class="nav-link text-light navbar-brand mb-1 " to="/Overseas">Overseas</Link>
        </li>
        <li >
          <Link class="nav-link text-light navbar-brand mb-1" to="/Contact">Contact</Link>
        </li>
        
        </ul>
        </div>
        
        
  
  




        
      
        
    )
    }
}