import React from 'react'
import './footheader.css'

import {Route} from 'react-router-dom'

import Home from './Home'
import Training from './Training'
import Adagency from './Adagency'
import Overseas from './Overseas'
import Contact from './Contact'
import Services from './Services'

import Navigation from './Navigation'
import Footerhead from './Footerhead'


export default class Footer extends React.Component{
    render(){
        return(<div>
       
        
        <Footerhead/>
        
       
         </div>)}
}