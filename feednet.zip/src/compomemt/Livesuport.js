import React from 'react'

export default class Support extends React.Component{
    render(){






        return(<div><h1>Ask Your Question To Us</h1>
        <p>The Feednet Solutions will drive perfection and initiative in India’s information, creation, and utilization of artificial intelligence (AI) to encourage financial development and improve the lives of Indians</p>
</div>  ) }
}