import React from 'react'

export default class extends React.Component{
    render(){
        return(<div><h1>payment</h1></div>)
    }
}