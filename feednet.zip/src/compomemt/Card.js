import React from 'react'
import { Carousel } from 'react-bootstrap'

import Image from './pics/webdeveloper.jpg'
import Image1 from './pics/datas.jpg'
import Image2 from './pics/IOT.jpg' 

import Image3 from './pics/DAT.jpg'
import './card.css'
export default class Card extends React.Component{
    render(){
        return(<div className="p-5 bg-dark">
<Carousel  indicators={true} interval={null} controls={null} className="m-3" >
  <Carousel.Item>
<div className="card-group">
<div className="card m-3 border" style={{width:"20rem"}} >
<div className="card-body position-relative">
<img  src={Image} width="100%"/>

<div className="overlay"></div>
<div className="social-bar1" style={{width:"100%"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>










<h4  className="border border-dark , guru"> GOPI </h4></div>
<p className="text-primary">web developer</p>

</div>


<div className="card m-3 border" style={{width:"20rem"}} >
<div className="card-body position-relative">
  
<img  src={Image1} width="100%"/>
<div className="social-bar1" style={{width:"100%",backgroundColor:"blue transperent"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>
<h4  className="border border-dark , guru2"> ASHOK KUMAR </h4></div>
<p className="text-primary">Data Scientist</p>

</div>


  



<div className="card m-3 border" style={{width:"20rem"}} >
<div className="card-body position-relative">
<img  src={Image2} width="98%"/>
<div className="social-bar1" style={{width:"100%"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>

<h4  className="border border-dark , guru3">SK MOINUDDIN </h4></div><br/>
<p className="text-primary">Automation Robotics,IOT</p>
</div></div></Carousel.Item><Carousel.Item>

<div className="card m-3 border " style={{width:"20rem"}} >
<div className="card-body position-relative">
<img  src={Image3} width="100%"/>
<div className="social-bar1" style={{width:"100%"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>
<h4  className="border border-dark , guru4"> SAMPATH </h4></div><br/>
<p className="text-primary">Lead Data Scientist</p>

</div>
</Carousel.Item>
</Carousel>



 

        </div>)
    }
} 