import React from 'react'
export default class Internship extends React.Component{
    render(){
        return(<diV>
<table>
<td>
<h1>We, at Feednet Solutions Private limited</h1>
<h2 className="text-light">" THE EXPERT IN ANYTHING WAS ONCE A BEGINNER "</h2>
<p className="text-left">
Internships are a very important part of our education program, first & foremost. In setting up professional internships, not only will we be able to offer students a chance to work with industry professionals, but the students will also be able to take the theory they learn in the classroom & practice here, in whichever activity they are focused.
We have 2 modules in our company for Artificial Intelligence Training:
Merit-Based Internship (Depends on your performance during the training)
Guaranteed Internship
</p>

< p className="text-primary">Along with the PGD course certification, the candidate will be provided 6 months experience certificate.</p>

        <div className="container m-3 p-3">
    <div className="container m-3">
        <input className="form-control m-3"placeholder="name"/>
    <input className="form-control m-3" placeholder="email"/>
    <input className="form-control m-3"placeholder="mobilenumber"/>
    <input className="form-control m-3"type="calender"placeholder="mm/dd/yy"/>
    <input className="form-control m-3"placeholder="Address"/>
    <input className="form-control m-3"placeholder="college name"/>
    <input className="form-control m-3"placeholder="specializing"/>
    <input className="form-control m-3"placeholder="applying for "/>
    <input className="form-control m-3"placeholder="percentage"/>

    <input type="file" className="form-control m-3" placeholder="Resume"/>
    {/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
    
    <button type= "submit">submit</button>

</div></div>







</td>










</table>










        </diV>)
    }
}

