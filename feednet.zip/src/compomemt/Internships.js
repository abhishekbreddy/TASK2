import React from 'react'
import {connect} from 'react-redux'
import store from './Redux/Store'
import {Link} from 'react-router-dom'
import Internsip from './Intershipform'
class Internship extends React.Component{


    constructor(props){
        super(props)
        this.state={
            userdata:this.props.storeData
        }
    }








    render(){
        return(<diV>

<div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>SERVICES DETAILS</h1></div>
<div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item"><Link TO="/corporate">TRAININGS</Link></li>
                        <li className="breadcrumb-item">Internships</li>
                    </ul></div>












<tr>
<td style={{width:"70%"}}  >
<div className="container p-3">
<h1 style={{fontSize:"25px",fontWeight:"400"}}>We, at Feednet Solutions Private limited</h1><br/>

<h3 style={{fontSize:"14px",fontWeight:"300"}}>" THE EXPERT IN ANYTHING WAS ONCE A BEGINNER "</h3><br/><p className="text-left">
Internships are a very important part of our education program, first & foremost. In setting up professional internships, not only will we be able to offer students a chance to work with industry professionals, but the students will also be able to take the theory they learn in the classroom & practice here, in whichever activity they are focused.
We have 2 modules in our company for Artificial Intelligence Training:
Merit-Based Internship (Depends on your performance during the training)
Guaranteed Internship
</p>

< p className="text-primary">Along with the PGD course certification, the candidate will be provided 6 months experience certificate.</p>
<div className="container-fluid ">


<h1 className="text-dark"style={{fontSize:"27px"}}> Apply for Internship</h1>


</div><Internsip/></div>














</td><td className="p-0">
<div className="card m-3">
                                  <div className="card-body p-3 text-left"><h1 className="text-dark p-2" style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>Openings</h1>
                                   <li className="p-1"style={{listStyle:"none"}}>Artificial Intelligence</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>Digital Marketing</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>AWS</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>Devops</li><br/>
                                  
                                   <li className="p-1"style={{listStyle:"none"}}>Web Development</li>
</div>
                </div>

                <div className="card m-3">
                                   <div className="card-body p-3"><h1 className="text-dark text-left p-1"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>Need help</h1>
                                   <div className="text-left p-3">
                                         <li style={{listStyle:"none"}}>
                                         <a href="https://www.google.com/maps/dir//feednetsolution/@17.4359666,78.3789042,14z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb91fe6992fceb:0x24fcbaa476a49d88!2m2!1d78.3844769!2d17.4447571" style={{color:"black"}}>
                         
                               
                                         <i class="fas fa-map-marker-alt  text-primary p-3"></i>&nbsp;{this.state.userdata.address}</a> </li>                   
   
<li  style={{listStyle:"none"}} ><i class="fas fa-phone  text-primary p-3"></i>{this.state.userdata.phoneno}</li><li style={{listStyle:"none"}}><i class="fas fa-envelope-open  text-primary p-3"></i>{this.state.userdata.email}</li>
</div>
 
                      
</div>
                </div> </td> </tr>





 


















        </diV>)
    }
}

export default connect((store)=>{
    return{
        storeData:store.Myreducer.initdata
    }
        
    })(Internship)
    