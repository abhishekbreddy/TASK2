import React from 'react'
import { Link } from 'react-router-dom'
import Image from './30.jpg'

export default class extends React.Component{
    render(){
        return(<div><table><tr>
            
            <td style={{width:'60%', height:'100%'}}>

             <img src ={{Image}} style={{width:'50%',height :'50%'}} />
             <div class="text-left">
            <h1>AI Solutions/Services</h1>
          <p>  
Today Machine Learning and Artificial Intelligence is penetrating every side of the business, from deploying Chatbots to AI-driven platforms. We help other businesses in building cutting-edge AI solutions that enable them to be a leader. Feednet Solutions leverages machine learning (ML), image recognition, and automatic speech recognition (ASR) technologies to the fullest benefit of its customers.

Being one of the competitive AI service providers we can help you achieve high-accuracy, high-quality AI capabilities that allow building cost-effective and highly scalable digital products and solutions. It will help you to achieve the advantage of minimized infrastructure and labour cost.

Artificial Intelligence can change the future of your company by transforming your businesses. Feednet Solutions understands and implements deep learning, natural language processing, and machine learning to ensure that we develop a powerful and reliable AI. Our Artificial Intelligence services & solutions for multiple industries enable faster decisions, reduce error, provide cognitive assistance, cut down costs, and avoid risk exposure to humans.</p></div></td>
            
            <td className ="p=3">
                <div className="card p-3 w-100">
                                   <div className="card-body p-3"><h1 className="text-dark">SERVICES</h1>
                                   <li className="p-1">AI Solutions/Services</li><br/>
                                   <li className="p-1">Product Development</li><br/>
                                   <li className="p-1">R&D</li><br/>
                                   <li className="p-1">Out Sourcing Employeesr</li><br/>
                                   <li className="p-1">Coworking Space</li><br/>
                                   <li className="p-1">Web Development</li>
</div>
                </div>

                <div className="card p-3 w-100">
                                   <div className="card-body p-3"><h1 className="text-dark">Need help</h1>
                                 
                                   P no 65, Vittal Rao Nagar, Madhapur, Hyderabad, Telangana 500081
   <li>+91 8639522961</li>
info@feednetsolution.com
</div>
                </div>
                </td>
                </tr>
                </table></div>)
    }
}