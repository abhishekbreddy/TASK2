import React from 'react'
import { Link } from 'react-router-dom'
import Image from './pics/Arti.jpg'
import {connect} from 'react-redux'

class Ai extends React.Component{
    constructor(props){
        super(props)
        this.state={
            userdata:this.props.Data
        }
    }

    render(){
        return(<div>
            <div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>SERVICES</h1></div>
<div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item"><Link TO="/Services">SERVICES</Link></li>
                        <li className="breadcrumb-item">AI</li>
                    </ul></div>
            
            
            
            
            
            <table><tr>
            
            <td style={{width:'70%', height:'100%'}}>
            <div className="container m-4">
             <img src ={Image} width='500px' height ='300px' />
             <div class="text-left p-2 my-5">
             
            <h1 className="p-2"style={{fontSize:"30px",fontWeight:"600"}}>AI Solutions/Services</h1>
          <p>  
Today Machine Learning and Artificial Intelligence is penetrating every side of the business, from deploying Chatbots to AI-driven platforms. We help other businesses in building cutting-edge AI solutions that enable them to be a leader. Feednet Solutions leverages machine learning (ML), image recognition, and automatic speech recognition (ASR) technologies to the fullest benefit of its customers.
</p><p>
Being one of the competitive AI service providers we can help you achieve high-accuracy, high-quality AI capabilities that allow building cost-effective and highly scalable digital products and solutions. It will help you to achieve the advantage of minimized infrastructure and labour cost.
</p><p>
Artificial Intelligence can change the future of your company by transforming your businesses. Feednet Solutions understands and implements deep learning, natural language processing, and machine learning to ensure that we develop a powerful and reliable AI. Our Artificial Intelligence services & solutions for multiple industries enable faster decisions, reduce error, provide cognitive assistance, cut down costs, and avoid risk exposure to humans.</p></div></div></td>
            
            <td className ="p-3">
                <div className="card m-3">
                
                                   <div className="card-body p-3 text-left"><h1 className="text-dark p-2"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>SERVICES</h1>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.userdata.ai}</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.userdata.pro}</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.userdata.rd}</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.userdata.out}</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.userdata.cow}</li><br/>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.userdata.web}</li>
</div>
                </div>

                <div className="card m-3">
                                   <div className="card-body p-3"><h1 className="text-dark text-left p-1"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>Need help</h1>
                                 <div className="text-left">
                                   <li style={{listStyle:"none"}}><a href="https://www.google.com/maps/dir//feednetsolution/@17.4359666,78.3789042,14z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb91fe6992fceb:0x24fcbaa476a49d88!2m2!1d78.3844769!2d17.4447571" style={{color:"black"}}>
                         
                               
                         <i class="fas fa-map-marker-alt  text-primary p-3"></i>&nbsp;{this.state.userdata.address}</a></li>
                         <li  style={{listStyle:"none"}} ><i class="fas fa-phone  text-primary p-3"></i>{this.state.userdata.phoneno}</li><li style={{listStyle:"none"}}><i class="fas fa-envelope-open  text-primary p-3"></i>{this.state.userdata.email}</li>
</div>
                </div></div>
                </td>
                </tr>
                </table></div>)
    }
}
export default connect((Store)=>{
    return{
          Data:Store.Myreducer.initdata
    }
})(Ai)