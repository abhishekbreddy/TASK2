export default function Info({ info }) {
    return (
      <div>
        <h1>{info.title}</h1>
        <p>{info.content}</p>
      </div>
    );
  }