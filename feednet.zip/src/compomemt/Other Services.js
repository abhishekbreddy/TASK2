import React from 'react'
import { Link } from 'react-router-dom'
import Image from './10.jpg'
import Image1 from './6.jpg'
import Image2 from './a.jpg'
import Image3 from './b.jpg'
import Image4 from './c.jpg' 
import Image5 from './d.jpg'
import Image6 from './e.jpg'

export default class extends React.Component{

render(){
  return(<div>
<div><table><tr>
  <td ><br></br><br></br><br></br>
    <div className="card-group">
<div className="card" style={{width:"20rem"}}>

  <div className="card-body">
 <img className="card-image-top" src={{Image}} />
  <h4 className="card-title card-link"> INTERNET OF THINGS </h4>
  <p>The Internet of Things (IoT) is a system of interrelated computing devices, mechanical and digital machines, objects, animals or people that are provided with unique identifiers</p>

  </div>
  
  
  
  
  </div> 
  <div className="card" style={{width:"20rem"}}>

<div className="card-body">
<img className="card-image-top" src={{Image1}} />
<h4 className="card-title card-link"> WEB DEVELOPMENT </h4>
<p>According to recent business statistics when it comes to hiring a web design or web development professionals, companies are becoming incredibly choosy....</p>

</div>




</div> 

<div className="card" style={{width:"20rem"}}>

<div className="card-body">
<img className="card-image-top" src={{Image2}} />
<h4 className="card-title card-link"> ANDROID/IOS DEVELOPMENT </h4>
<p>Android is a mobile operating system developed by Google. It is based on a modified version of the Linux kernel and other open source software
</p></div></div></div>
<div className="card-group">
<div className="card" style={{width:"20rem"}}>

<div className="card-body">
<img className="card-image-top" src={{Image3}} />
<h4 className="card-title card-link"> DIGITAL MARKETING </h4>
<p>Digital Marketing is the branch of marketing through which one can do the marketing of products or services using digital technologies like facebook, twitter, instagram etc.
</p></div></div>

<div className="card" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top" src={{Image4}} />
<h4 className="card-title card-link">OUT SOURCING EMPLOYEES </h4>
<p>Outsourcing Employment is easiest and fastest way to hire employees in countries where you do not have a legal entity or where you are not allowed to hire people for any reason.
</p></div></div>


<div className="card" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top" src={{Image5}} />
<h4 className="card-title card-link">COWORKING SPACE </h4>
<p>Feednet Solution is Situated in the prime business area of Madhapur, and is additionally near Hi-Tech City, with all significant IT organizations situated inside a 2 km span.
</p></div></div></div>
<div className="card-group">
<div className="card" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top" src={{Image6}} />
<h4 className="card-title card-link"> AD AGENCY</h4>
<p>An advertising agency, often referred to as a creative agency or an ad agency, is a business dedicated to creating, planning, and handling advertising and sometimes other forms..
</p></div></div></div>









    </td>        
            
            <td className ="p=3">
                <div className="card p-0 w-100 ">
                                   <div className="card-body p-3"><h1 className="text-dark">SERVICES</h1>
                                   <li className="p-1">AI Solutions/Services</li><br/>
                                   <li className="p-1">Product Development</li><br/>
                                   <li className="p-1">R&D</li><br/>
                                   <li className="p-1">Out Sourcing Employeesr</li><br/>
                                   <li className="p-1">Coworking Space</li><br/>
                                   <li className="p-1">Web Development</li>
</div>
                </div>

                <div className="card p-3 w-100 h-50 m-y-1">
                                   <div className="card-body p-3"><h1 className="text-dark">Need help</h1>
                                 
                                 <li className="p-1">  P no 65, Vittal Rao Nagar, Madhapur, Hyderabad, Telangana 500081</li>
   <li className="p-1">+91 8639522961</li>
<li className="p-1">info@feednetsolution.com</li>
</div>
                </div>
                </td>
                </tr>
                </table></div>



  </div>)
}


}  