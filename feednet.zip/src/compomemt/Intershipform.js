import react, { useState } from 'react'

export default function Intern(){

    const [name,setName]=useState("")
    const [phno,setPhno]=useState(0)
    const [email,setEmail]=useState("")
    const [college,setCollege]=useState("")
    const [specializing,setSpecializing]=useState("")
    const [Applyfor,setApplyfor]=useState(0)
    const [percentage,setPercentage]=useState(0)
    const [yearofpassing,setYearofpassing]=useState(0)
    const [Address,setAddress]=useState(0)
    const [date,setDate]=useState(0)
    const  [resume,setResume]=useState("")


      
    return(<div>

<div>
   
        <div className="input-group"style={{width:"100%"}}>
    <input className="form-control m-3" style={{width:"10%"}}placeholder="name"onChange={(event)=>{setName(event.target.value)}}/>
<input className="form-control m-3 "style={{width:"10%"}} placeholder="email"onChange={(event)=>{setEmail(event.target.value)}}/></div>
<div className="input-group" style={{width:"100%"}}>
<input className="form-control m-3"placeholder="mobilenumber"onChange={(event)=>{setPhno(event.target.value)}}/>
<input className="form-control m-3"type="date"placeholder="mm/dd/yy"onChange={(event)=>{setDate(event.target.value)}}/></div>
<div className="input-group"style={{width:"100%"}}>
<input className="form-control m-3"placeholder="Address"onChange={(event)=>{setAddress(event.target.value)}}/></div>
<div className="input-group"style={{width:"100%"}}>
<input className="form-control m-3"placeholder="college name"onChange={(event)=>{setCollege(event.target.value)}}/></div>
<div className="input-group"style={{width:"100%"}}>
<input className="form-control m-3 m-r-3"placeholder="specializing"onChange={(event)=>{setSpecializing(event.target.value)}}/>
<input className="form-control m-3 m-r-3"placeholder="applying for "onChange={(event)=>{setApplyfor(event.target.value)}}/></div>
<div className="input-group"style={{width:"100%"}}>
<input className="form-control m-3 "placeholder="year of passing"onChange={(event)=>{setYearofpassing(event.target.value)}}/>
<input className="form-control m-3"placeholder="percentage"/></div>
<div className="input-group"style={{width:"100%"}}>
<input type="file" className="form-control m-3 m-l-3" placeholder="Resume"onChange={(event)=>{setResume(event.target.value)}}/></div>
{/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}

<button type= "submit">submit</button></div>







    </div>)
}