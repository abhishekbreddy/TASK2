import React from 'react'
import {Carousel} from 'react-bootstrap' 
import Cardcarasoul from './Card'
import { connect } from 'react-redux'
import Image from './pics/webdeveloper.jpg'
import Image1 from './pics/datas.jpg'
import Image2 from './pics/IOT.jpg' 

import Image3 from './pics/DAT.jpg' 
import './About.css'
import Store from './Redux/Store'
import {Link }from 'react-router-dom'

import Robo from './Robo'
 class About extends React.Component{
    constructor(props){
        super(props)
        this.state={
            userdata:this.props.storeData
        }
        console.log(this.state.userdata)
    }

    

 // state={
    //     apiData:[]
    // }
    
    
    // 
    

    // submit=()=> {
    //     alert("ok")
    //      Axios.post("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
    //             this.setState({
    //                 data:res.data
    //             })
    //             apiData.data =res.data
    //           console.log("apidata",apiData.data)
    //      },(err)=>{
    //        alert(err)
    //      })
    // }

  render(){
        return(<div><div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>ABOUT</h1></div>
        <div><ul class="breadcrumb text-center">
                                <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                                
        
                                <li className="breadcrumb-item">About</li>
                            </ul></div>



<Robo/>










<div>
                <h1 className="p-3">Work Process</h1>
                <h1 style={{fontSize:"16px"}}>__ ____ __</h1>
<div className="card-group">
        <div className="card m-3 " style={{width:"20rem", height :"10rem",borderTop:"2px solid blue"}}>
        
          <div className="card-body">
          <i class="fas fa-newspaper w-3 h-3 fa-3x"></i>
          <h4 className="card-title">Discuss</h4>
        </div>
        
        <div className="overlay">
        <div className="card-body ">
          <i class="fas fa-newspaper w-3 h-3 fa-3x"></i>
          <h4 className="card-title">Discuss</h4>
        </div>





        </div>

          </div>
          
          <div className="card m-3 border" style={{width:"20rem",backgroundColor:"#008CBA"}}>
        
        <div className="card-body">
        <i class="fas fa-chart-line w-3 h-3 fa-3x" style={{color:'white'}}></i>
        <h4 className="card-title text-light">Analysis</h4>
</div> </div>



        <div className="card m-3 " style={{width:"20rem", height :"10rem",borderTop:"2px solid blue"}}>
        
        <div className="card-body ">
        <i class="fas fa-check-double w-3 h-3 mt fa-3x"></i>
        <h4 className="card-title ">Launch </h4></div>
        <div className="overlay">
        <div className="card-body">
          <i class="fas fa-check-double w-3 h-3 fa-3x"></i>
          <h4 className="card-title">Launch</h4>
        </div>





        </div>





        </div>
        
        
        
        
        
        
        </div>
        
        
        </div>























            <div>
                <h1 className="p-3">what we offer</h1>
<div className="card-group">
        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
        
          <h4 className="card-title">{this.state.userdata.ai}</h4><p>Today Machine Learning and Artificial Intelligence is penetrating every side of the business, from deploying Chatbots to AI-driven platforms</p>
        </div>
          </div>
          
          <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
      
        <h4 className="card-title">{this.state.userdata.rd}</h4>
<p>R&D – is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell.</p>        </div>

</div>
        <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
       
        <h4 className="card-title">{this.state.userdata.pro} </h4>
        <p>
        Product development is a creation of new or different product that offers benefits to the end user includes both creation of an new product and modifications to an existing product
        </p>

      </div>
        </div></div>







            <div className="card-group">
        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
        
          <h4 className="card-title">{this.state.userdata.out}</h4><p>Outsourcing Employment is easiest and fastest way to hire employees in countries where you do not have a legal entity or where you are not allowed to hire people for any reason</p>
        </div>
          </div>
          
          <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
      
        <h4 className="card-title">{this.state.userdata.cow}</h4>
        <p>Feednet Solution is Situated in the prime business area of Madhapur, and is additionally near Hi-Tech City, with all significant IT organizations situated inside a 2 km span.</p> </div>
        </div>


        <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
       
        <h4 className="card-title">CORPORATE TRAINING </h4>
        <p>
        To bridge competency gap towards building skilled and productive workforce to meet the challenges of global business competitions by corporates.

        </p>

      </div>
        </div></div></div>
            
        <div className="card-group">
        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
        
          <h4 className="card-title ">Call us</h4><p>{this.state.userdata.phoneno}</p>
        </div>
          </div>
          
          <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
      
        <h4 className="card-title">Address</h4>
        <p>{this.state.userdata.address}</p> </div>
        </div>

         
        <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
       
        <h4 className="card-title "> email </h4>
        <p>{this.state.userdata.email}</p>

      </div>
        </div></div>


        





<Cardcarasoul/>



{/* 
        <div className="card m-3" style={{width:"20rem"}} >
<div className="card-body position-relative">
<img  src={Image} width="100%"/>


<div className="social-bar1" style={{width:"100%"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>










<h4  className="border border-dark , guru"> GOPI </h4></div>
<p className="text-primary">web developer</p>

</div>


<div className="card m-3" style={{width:"20rem"}} >
<div className="card-body position-relative">
  
<img  src={Image1} width="100%"/>
<div className="social-bar1" style={{width:"100%"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>
<h4  className="border border-dark , guru2"> ASHOK KUMAR </h4></div>
<p className="text-primary">Data Scientist</p>

</div>


  



<div className="card m-3" style={{width:"20rem"}} >
<div className="card-body position-relative">
<img  src={Image2} width="100%"/>
<div className="social-bar1" style={{width:"100%"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>

<h4  className="border border-dark , guru3">SK MOINUDDIN </h4></div><br/>
<p className="text-primary">Automation Robotics,IOT</p>

</div>
<div className="card m-3" style={{width:"20rem"}} >
<div className="card-body position-relative">
<img  src={Image3} width="100%"/>
<div className="social-bar1" style={{width:"100%"}}>
         
        
            <a className="p-3" href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
        
        
            <a className="p-3" href="https://twitter.com/FeednetS"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          
      
            <a className="p-3" href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          
          
            <a className="p-3"href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
        
         
       </div>
<h4  className="border border-dark , guru4"> SAMPATH </h4></div><br/>
<p className="text-primary">Lead Data Scientist</p>

</div> */}
















        
        

        <div>
        <div className="p-3">
        <div className="container-fluid p-3" style={{backgroundColor:"whitesmoke"}}>
          <h1>lets talk about your new idea</h1>
          <div className="input-group">
        <input className="form-control m-3"placeholder="name" style={{width:"10%"}}/>
        <input className="form-control ml-2 mt-3 mr-0"placeholder="mobilenumber"/>
        </div>
    <input className="form-control m-3" placeholder="email"/>
    
    <input className="form-control m-3"placeholder="Projects"/>

    
    <button>submit</button></div></div>
    </div>
<div class="maps-area">
        <div class="container-fluid">
            <div class="row">
                <div class="google-maps">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.313458260684!2d78.38223431487712!3d17.444704888044264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x24fcbaa476a49d88!2sFeednet+Solutions+Pvt+Ltd.!5e0!3m2!1sen!2sin!4v1566480097247!5m2!1sen!2sin" width="1300" height="450" frameborder="0" style={{border:"0"}} allowfullscreen=""></iframe>
                </div>
            </div>
        </div>
    </div>
          
          
          
          
          
</div>    
  )
}
}
export default connect((Store)=>{
    return{
        storeData:Store.Myreducer.initdata
    }
        
    })(About)