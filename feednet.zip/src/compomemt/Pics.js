import React from 'react'
import Robo from './pics/robo.png'

export default class Pics extends React.Component{
        render(){
                return(<div className="container"><img src={{Robo}}></img></div>)
        }}