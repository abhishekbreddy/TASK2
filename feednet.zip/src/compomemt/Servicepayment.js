import React from 'react'
 
export default class Coursepayment extends React.Component{

    // 
    

    // submit() {
    //     alert("ok")
    //      Axios.post("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
    //             this.setState({
    //                 data:res.data
    //             })
    //             apiData.data =res.data
    //           console.log("apidata",apiData.data)
    //      },(err)=>{
    //        alert(err)
    //      })
    // }


render(){

    return(<div className="container m-3 p-3">
    <div className="container m-3">
        <input className="form-control m-3"placeholder="name"/>
    <input className="form-control m-3" placeholder="email"/>
    <input className="form-control m-3"placeholder="mobilenumber"/>
    <select className="form-control m-3"><option> Artificial solutions</option><option>website development </option><option>Ad shots</option><option> mobile App Development</option><option>Digital Marketing</option><option>Other Services</option></select>
    <input className="form-controlm-3"placeholder="amount"/>
    <button>paynow</button></div></div> )} }