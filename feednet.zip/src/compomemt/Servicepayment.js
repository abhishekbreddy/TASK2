import React from 'react'
import { Route } from 'react-router-dom'
 import './sevicepayment.css'
 import {useState} from 'react'

export default function Coursepayment () {

    const [name,setName]=useState("")
    const [phno,setPhno]=useState(0)
    const [email,setEmail]=useState("")
    const [comments,setComments]=useState("")
    const [service,setService]=useState("")
    const [oservice,setOservice]=useState("")
    const [amount,setAmount]=useState(0)

    
    const display=()=>{
      console.log(name + phno + comments + service + oservice + email + amount)
    }

    function handleChange(newValue) {
      setOservice(newValue);
    }









    return(<div className="container bg-dark">
        
<div className="row m-3 p-4">
    <div className="col-sm-3 bg-primary">
       
        
            
        <div className="contact-header"style={{whiteSpace:"nowrap"}}><h3 style={{fontSize:"25px",fontWeight:"600"}}>⎯⎯⎯⎯&nbsp;&nbsp;SERVICE &nbsp;PAYMENT</h3></div>
        <div className="social-bar1 text-light" style={{display:"flex",transform:"rotate(-90deg)",left:"30%",top:"85%"}}>
         <ul>
           <li>
            <a href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f text-light" aria-hidden="true"style={{transform:"rotate(90deg)"}}></i></a>
          </li>
          <li>
            <a href="https://twitter.com/FeednetS"><i class="fab fa-twitter text-light" aria-hidden="true"style={{transform:"rotate(90deg)"}}></i></a>
          </li>
          <li>
            <a href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram text-light" aria-hidden="true" style={{transform:"rotate(90deg)"}}></i></a>
          </li>
          <li>
            <a href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin text-light" style={{transform:"rotate(90deg)"}} aria-hidden="true"></i></a>
          </li>
         </ul>
       </div>
         
        
</div><div className="col-sm-8 p-5" style={{ backgroundColor:'whitesmoke'}}>
         <h1 className="ml-5"> service payment</h1>  
     <div className="col-sm-11 m-4 bg-light">
          <div className="input-group" >
         <input type="text" name="name" placeholder="Name" onChange={(event)=>{setName(event.target.value)}} style={{borderBottom: "2px  gray",width:"45%",outline:"none"}} />
         <input className="mt-2 ml-3" type="number"name="phno" placeholder="Mobile Number"style={{width:"50%",outline:"none"}} onChange={(event)=>{setPhno(event.target.value)}}  />
         </div>
         <div className="input-group">
         <input type="email" name="email" placeholder="Email" onChange={(event)=>{setEmail(event.target.value)}} style={{outline:"none"}}/></div>
         <div className="input-group">
         <textarea rows="4" style={{width:"100%",backgroundColor:"whitesmoke",outline:"none",border:"0px"}}placeholder="Comments" name="comment"onChange={(event)=>{setComments(event.target.value)}}></textarea></div>

         <div className="input-group">
{/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
<select className="form-control mt-3" style={{backgroundColor:"whitesmoke",width:"100%",outline:"none"}} onChange={(event)=>{setService(event.target.value)}}>
      <option value="">Select Service</option>
      <option value="AI Solution">AI Solution</option>
      <option value="Web Site Development">Web Site Development</option>
      <option value="Ad Shots">Ad Shots</option>
      <option value="Mobile App Development">Mobile App Development</option>
      <option value="Digital Marketing">Digital Marketing</option>
      <option value="Other services">Other Services</option>
            
    </select></div>
    <div className="input-group">
   {service==="Other services" && (<Professional onChange={handleChange}></Professional>)}
    
     <input  className="mt-3"type="number" placeholder="Amount"onChange={(event)=>{setAmount(event.target.value)}} style={{outline:"none"}}/></div></div>
<button  onClick={display} className="btn btn-primary  , guru1" type="submit"><h3>Pay Now</h3></button>
   









 
</div>
        </div>
    </div>)
}

const Professional=(props)=>{

 function handleChange(event) {
// Here, we invoke the callback with the new value
     props.onChange(event.target.value);
 }


 return(<input  className="m-3"style={{outline:"none"}} onChange={handleChange}/>);
}