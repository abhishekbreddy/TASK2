import React from 'react'
import './footer.css'

export default class Footer extends React.Component{
    render(){
        return(<div><p className = "footer">© Copyright 2019. All Rights Reserved by<span className ="para"> Feednetsolutions</span></p> </div>)
    }
}