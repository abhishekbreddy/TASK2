import React from 'react'
export default class Ourstory extends React.Component{
    render(){
        return(<div><h1>We Have Ample Experience In Standard Professional Services</h1>
        <p>The Feednet Solutions will drive perfection and initiative in India’s information, creation, and utilization of artificial intelligence (AI) to encourage financial development and improve the lives of Indians.</p>
        <p>Feednet Solutions endeavours to draw in the best worldwide ability concentrated on research brilliance in deep learning and machine learning. Our analysts and academic partners are a piece of a dynamic network of imaginative issue solvers, working across disciplines on both interests driven and connected research.</p>
        </div>)
    }
}