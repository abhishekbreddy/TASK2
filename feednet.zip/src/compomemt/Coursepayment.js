import React from 'react'
import { Route } from 'react-router-dom'
import './Coursepayment.css'
import {useState} from 'react' 
export default function Coursepayment(){
  const [name,setName]=useState("")
  const [phno,setPhno]=useState(0)
  const [email,setEmail]=useState("")
  const [comments,setComments]=useState("")
  const [course,setCourse]=useState("")
  const [ocourse,setOcourse]=useState("")
  const [amount,setAmount]=useState(0)
    
  function handleChange(newValue) {
    setOcourse(newValue);
  }

  
  

  // const onSubmit = () => {
  //   Axios.post("http://localhost:3001/create", {     // APIKEY OR URL IN DOUBLE QUOTES
  //     name: name,               //KEY VALUE SHOULD BE SAME AS IN BACKEND() 
  //     phno: phno,               //left one is the backend key, 
  //     email: email,
  //     comments: comments,
  //     course: course,
  //        ocourse:ocourse,
  //   }).then(() => {
  //     console.log()
  //   });
  // };
    


 

    // submit() {
    //     alert("ok")
    //      Axios.post("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
    //             this.setState({
    //                 data:res.data
    //             })
    //             apiData.data =res.data
    //           console.log("apidata",apiData.data)
    //      },(err)=>{
    //        alersrt(err)
    //      })
    // }





    return(<div className="container bg-dark">
        
<div className="row m-3 p-4">
    <div className="col-sm-3 bg-primary">
       
        
            
        <div className="contact-header"style={{whiteSpace:"nowrap"}}><h3 style={{fontSize:"25px",fontWeight:"600"}}>⎯⎯⎯⎯&nbsp;&nbsp;COURSE &nbsp;PAYMENT</h3></div>

        <div className="social-bar1 text-light " style={{display:"flex",transform:"rotate(-90deg)",left:"20%",top:"80%"}}>
         <ul>
           <li>
            <a href="https://www.facebook.com/feednetsolutions/"><i class="fab fa-facebook-f text-light" aria-hidden="true"style={{transform:"rotate(90deg)"}}></i></a>
          </li>
          <li>
            <a href="https://twitter.com/FeednetS"><i class="fab fa-twitter text-light" aria-hidden="true"style={{transform:"rotate(90deg)"}}></i></a>
          </li>
          <li>
            <a href="https://www.instagram.com/feednetsolutions/"><i class="fab fa-instagram text-light" aria-hidden="true" style={{transform:"rotate(90deg)"}}></i></a>
          </li>
          <li>
            <a href="https://www.linkedin.com/company/feednet-solutions-pvt-ltd"><i class="fab fa-linkedin text-light" style={{transform:"rotate(90deg)"}} aria-hidden="true"></i></a>
          </li>
         </ul>
       </div>









        
</div><div className="col-sm-8 p-5" style={{ backgroundColor:'whitesmoke'}}>
         <h1 className="ml-5"> course payment</h1>  
     <div className="col-sm-11 m-4 bg-light">
     <div className="input-group">
         <input type="text" name="name" placeholder="Name" onChange={(event)=>{setName(event.target.value)}} style={{borderBottom: "2px solid gray",width:"45%", outline:"none"}} />
         <input className="mt-2 ml-3" type="number"name="phno" placeholder="Mobile Number"style={{width:"50%",outline:"none"}} onChange={(event)=>{setPhno(event.target.value)}} />
         </div>
         <input type="email" name="email" placeholder="Email" onChange={(event)=>{setEmail(event.target.value)}} style={{outline:"none"}}/>
         <textarea rows="4" style={{width:"100%",backgroundColor:"whitesmoke"}}placeholder="Comments" name="comment" onChange={(event)=>{setComments(event.target.value)}} style={{outline:"none"}}></textarea>
{/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
        <select className="form-control m-1" style={{backgroundColor:"whitesmoke",width:"100%"}} onChange={(event)=>{setCourse(event.target.value)}}>
        {/* {header} */}
      
      <option value="Select Service">select course</option>
      <option value="Internship for Artificial Intellegence">Internship for Artificial Intellegence</option>
      <option value="Data science with python">Data science with python</option>
      <option value="Python Full Stack">Python Full Stack</option>
      <option value="AWS/Azure/Gcloud">AWS/Azure/Gcloud</option>
    
      <option value="Other Trainings" >Other Trainings</option>
       
      
    </select>
    {
    course==="Other Trainings" && (<Professional  onchange={handleChange}/>) 
} 
{
     console.log(course)
    }
    
  
   <input type="number" placeholder="Amount" onChange={(event)=>{setAmount(event.target.value)}} style={{outline:"none"}}/></div>
<button className="btn btn-primary  , guru1" type="submit"><h3>Pay Now</h3></button>
   









 
</div>
        </div>
    </div>)
}

const Professional=(props)=>{

  function handleChange(event) {
    // Here, we invoke the callback with the new value
         props.onChange(event.target.value);
     }
 



  return(<div><input placeholder="add trainings" onChange={handleChange}/>
  
  
  </div>
  );
}