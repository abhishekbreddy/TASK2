import React from 'react'
import {Route} from 'react-router-dom'
import Home from './Home'
import Training from './Training'
import Adagency from './Adagency'
import Overseas from './Overseas'
import Contact from './Contact'
import Services from './Services'

