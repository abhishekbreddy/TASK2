import React from 'react' 
import Img from 'E:/feednet/feednet/src/logo-light.png'
import Navigation from './Navigation'

 export default class Footerhead extends React.Component{
    render(){
        return(<div><table><tr><td style={{width: '35%',backgroundColor:"#002147" }}><img src={Img}/></td><td className = "fheader text-light"style={{backgroundColor:"#002147"}}><h1 style={{fontSize:"20px",fontWeight:"700",paddingRight:"20px",paddingTop:"20px"}}>ABOUT FEEDNET</h1>
        <p style={{fontSize:"17px",fontWeight:"400",color:"white"}}>
        Feednet Solutions endeavours to draw in the best worldwide ability concentrated on research brilliance in deep learning and machine learning. Our analysts and academic partners are a piece of a dynamic network of imaginative issue solvers, working across disciplines on both interests driven and connected research.</p></td></tr></table>
        
   
    <Navigation/>  </div>)
    }
}