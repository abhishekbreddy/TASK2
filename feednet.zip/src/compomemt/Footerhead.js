import React from 'react' 
import Img from 'E:/feednet/feednet/src/logo-light.png'
import Navigation from './Navigation'

 export default class Footerhead extends React.Component{
    render(){
        return(<div><table><tr><td style={{width: '50%',backgroundColor:"blueviolet" }}><img src={Img}/></td><td className = "fheader"><h1>ABOUT FEEDNET</h1>
        Feednet Solutions endeavours to draw in the best worldwide ability concentrated on research brilliance in deep learning and machine learning. Our analysts and academic partners are a piece of a dynamic network of imaginative issue solvers, working across disciplines on both interests driven and connected research.</td></tr></table>
        <Navigation/>  </div>)
    }
}