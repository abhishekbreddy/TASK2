import React from 'react'
import Image from './pics/Seminar1.jpg'
import Image1 from './pics/seminars2.jpg' 
import Image4 from './pics/Image4.jpg'
import {connect} from'react-redux'
import {Link} from 'react-router-dom'
import store from './Redux/Store'

  class Workshop extends React.Component{

    constructor(props){
      super(props)
      this.state={
          userdata:this.props.storeData,
          name:"",
          mobileno:"",
          email:"",
        designation:""
      }
  }


          
handleChangeName=(event)=>{
       
  this.setState({
   name :event.target.value,
  
  })


}

handleChangeMobileno=(event)=>{
 
  this.setState({
   mobileno :event.target.value,
  
  })
}  
handleChangeEmail=(event)=>{
 
  this.setState({
   email:event.target.value,
  
  })
}  
handleChangeDesignation=(event)=>{
 
  this.setState({
   designation :event.target.value,
  
  })
}




    render(){
        return(<div>

<div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>SERVICES DETAILS</h1></div>
<div><ul class="breadcrumb float-centre">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item"><Link TO="/corporate">TRAININGS</Link></li>
                        <li className="breadcrumb-item">Workshops</li>
                    </ul></div>














          <div className="card-group">
        <div className="card" style={{width:"20rem"}}> 
        
          
         <img src= {Image} />
          
        
          </div>

          
        <div className="card">
        
       <img  src= {Image1} />
        </div>


        <div className="card" style={{width:"20rem"}}>
        
          
         <img className="card-image-top" src={Image4} />
          </div>

          

        <div className="card" style={{width:"20rem"}}>
        
          
         <img  src={Image1} />
          
        </div></div>
        
                 
          
           <td className="w-1 text-left"  style={{width:"70%"}}><div className="container p-3">
           <h1 style={{fontSize:"35px",fontWeight:"700",color:"lightblue"}}> We Provide Workshops On </h1><br/>
               <h3 className="fa fa-check" style={{fontSize:"18px",fontWeight:"600",}}> Artificial Intelligence:</h3>
               <p>Artificial intelligence (AI) is intelligence displayed by machines, and it's often used to improve and automate software processes. Perhaps the most well-known AI is SIRI, Apple's Speech Recognition software.However, AI has now become a mainstream technology that many people and companies use on a daily basis</p>         

               <h1 className="text-primary"style={{fontSize:"33px",fontWeight:"700"}} >Artificial intelligence </h1>
               <h2 className="fa fa-check" style={{fontSize:"20px",fontWeight:"500",fontFamily:"sans-serif"}} >AI Workshop Includes Basic Knowledge On:</h2>
               <h3 className="text-primary text-left"style={{fontSize:"20px",fontWeight:"700"}}>statistics</h3>
               <li>Qualitative & Quantitative Data</li>
<li>Measures of Central Tendency(mean, median &mode)</li>
<li>Measures of Dispersion(variance,Standard Deviation & Variance)</li>
<li>Data Exploration(histograms, barplot, boxplot, scatterplot</li><br/>
<h3 className="text-primary text-left"style={{fontSize:"20px",fontWeight:"700"}}>Python</h3>
<li>Installation</li>
<li>Basic syntax</li>
<li>Basic Data Types</li>
<li>functions</li>
<li>modules</li>
<li>Packages</li>
<li>Python Standard Libraries(Numpy,Scipy,Pandas)</li>
<h3 className="text-primary text-left"style={{fontSize:"20px",fontWeight:"700"}}>Machine learning</h3>


<li>What is Machine learning</li>
<li>why it is used</li>
<li>Types of Machine learning </li>
<li>Supervised Learning</li>
<li>Unsupervised Learning</li>
<li>Reinforcement Learning</li>
<li>Applications of Machine Learning</li>
<li>Future vision of Machine Learning</li>

<div className="container-fluid m-3" style={{backgroundColor:'lightblue'}}>


<h1 className="text-dark text-centre">Contact For Workshops In Your College</h1>

   
        <div className="input-group"style={{width:"100%"}}>
    <input className="form-control m-3" placeholder="name" onChange={this.handleChangeName}/>
    <input className="form-control m-3"placeholder="mobilenumber"onChange={this.handleChangeMobileno}/></div>

    <div className="input-group"style={{width:"100%"}}>
<input className="form-control m-3"style={{width:"100%"}} placeholder="email"onChange={this.handleChangeEmail}/>
<input className="form-control m-3" style={{width:"100%"}} placeholder="designation',ex.principalHOD,top"onChange={this.handleChangeDesignation}/></div>

{/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}

<button  className="float-centre"type= "submit">submit</button>

</div></div>















</td><td className ="p=3">
<div className="card m-3">
                                   <div className="card-body p-3 text-left"><h1 className="text-dark p-2"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>SERVICES</h1>
                              <div className="p-1">     <li className="p-1"style={{listStyle:"none"}}>{this.state.ai}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.pro}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.rd}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.out}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.cow}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.web}</li>
</div></div>
                </div>

                <div className="card m-3">
                                   <div className="card-body p-3"><h1 className="text-dark text-left p-1"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>Need help</h1>
                                 <div className="text-left p-3">
                                         <li style={{listStyle:"none"}}>
                                         <a href="https://www.google.com/maps/dir//feednetsolution/@17.4359666,78.3789042,14z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb91fe6992fceb:0x24fcbaa476a49d88!2m2!1d78.3844769!2d17.4447571" style={{color:"black"}}>
                         
                               
                                         <i class="fas fa-map-marker-alt  text-primary p-3"></i>&nbsp;{this.state.address}</a> </li>                   
   
<li  style={{listStyle:"none"}} ><i class="fas fa-phone  text-primary p-3"></i>{this.state.phoneno}</li><li style={{listStyle:"none"}}><i class="fas fa-envelope-open  text-primary p-3"></i>{this.state.email}</li>
</div></div>
                </div>
    
    
    </td></div>)
    }
}
export default connect((store)=>{
  return{
      storeData:store.Myreducer.initdata
  }
      
  })(Workshop)