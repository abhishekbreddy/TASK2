import React from 'react'

 export default class Workshop extends React.Component{
    render(){
        return(<div>
          <div className="card-group">
        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> RESEARCH & DEVELOPMENT </h4>
          <p>R&D – is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell.</p>
        
          </div></div>

          
        <div className="card">
        <div className="card-body">
       <img className="card-image-top" src={{Image}} />
        <h4 className="card-title card-link"> RESEARCH & DEVELOPMENT </h4>
        <p>R&D – is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell.</p>
      
        </div></div>


        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> RESEARCH & DEVELOPMENT </h4>
          <p>R&D – is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell.</p>
        
          </div></div>

          

        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> RESEARCH & DEVELOPMENT </h4>
          <p>R&D – is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell.</p>
        </div></div></div>
        
        <div>
          <table>
           <td className="w-3">
           <h1 className="text-primary"> We Provide Workshops On </h1><br/>
               <h3> Artificial Intelligence:</h3>
               <p>Artificial intelligence (AI) is intelligence displayed by machines, and it's often used to improve and automate software processes. Perhaps the most well-known AI is SIRI, Apple's Speech Recognition software.However, AI has now become a mainstream technology that many people and companies use on a daily basis</p>         


               <h2>AI Workshop Includes Basic Knowledge On:</h2>
               <h3 className="text-primary text-left">statistics</h3>
               <li>Qualitative & Quantitative Data</li>
<li>Measures of Central Tendency(mean, median &mode)</li>
<li>Measures of Dispersion(variance,Standard Deviation & Variance)</li>
<li>Data Exploration(histograms, barplot, boxplot, scatterplot</li><br/>
<h3 className="text-primary">Python</h3>
<li>Installation</li>
<li>Basic syntax</li>
<li>Basic Data Types</li>
<li>functions</li>
<li>modules</li>
<li>Packages</li>
<li>Python Standard Libraries(Numpy,Scipy,Pandas)</li>
<h3 className="text-primary">Machine learning</h3>


<li>What is Machine learning</li>
<li>why it is used</li>
<li>Types of Machine learning </li>
<li>Supervised Learning</li>
<li>Unsupervised Learning</li>
<li>Reinforcement Learning</li>
<li>Applications of Machine Learning</li>
<li>Future vision of Machine Learning</li>
</td><td>
<div className="card  w-100 m-3">
                                  <div className="card-body p-3"><h1 className="text-dark">SERVICES</h1>
                                   <li className="p-1">AI Solutions/Services</li><br/>
                                   <li className="p-1">Product Development</li><br/>
                                   <li className="p-1">R&D</li><br/>
                                   <li className="p-1">Out Sourcing Employeesr</li><br/>
                                   <li className="p-1">Coworking Space</li><br/>
                                   <li className="p-1">Web Development</li>
</div>
                </div>

                <div className="card p-3 w-100">
                                   <div className="card-body p-3"><h1 className="text-dark">Need help</h1>
       <li>{this.props.state}</li>
       <li>{this.props.phoneno}</li>                          
 
</div></div>
    
    
    </td></table> </div></div>)
    }
}