import React from 'react'
import Internship from './Workshops'
export default class extends React.Component{
    render(){
        return(<div><Internship/>
        </div>)
    }
}