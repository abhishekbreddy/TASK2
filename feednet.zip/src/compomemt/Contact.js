import React from 'react'
import Pics from './Pics'
import Internships from './Pics'
export default class Contact extends React.Component{
    render(){
        return(<div><Internships/>
        </div>)
    }
}