import React from 'react'
import Imaq from './pics/q.jpg' 
import Imaw from './pics/w.jpg'
import Imaf from './pics/f.jpg'
import {Link} from 'react-router-dom'
import './Corporate.css'
import {useState} from 'react'

export default function Courses (){

  const [name,setName]=useState("")
  const [mobile,setMobile]=useState(0)
  const [email,setEmail]=useState("")
  
  const [city,setCity]=useState("")
  const [Intrested,setIntrested]=useState(0)




 
    // 
    

    // submit=()=> {
    //     alert("ok")
    //      Axios.post("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
    //             this.setState({
    //                 data:res.data
    //             })
    //             apiData.data =res.data
    //           console.log("apidata",apiData.data)
    //      },(err)=>{
    //        alert(err)
    //      })
    // }

 
        return(<div>
          
          <div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>OUR COURSES</h1></div>
<div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item">COURSES</li>
                        
                    </ul></div>
          
          
          
          
          
          
          
          
          
          
          
          <div className="card-group m-3">
        <div className="card p-3" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top m-3" src= {Imaq} width="150" height="100"/>
          <h4 className="card-title card-link" style={{fontSize:"18px",fontWeight:"600"}}>ARTIFICIAL INTELLIGENCE  </h4>
          <p>Artificial intelligence (AI) is an area of computer science that emphasizes the creation of intelligent machines that work and react like humans</p>
        </div>
          </div>
          
          <div className="card p-3" style={{width:"20rem"}}>
        
        <div className="card-body">
       <img className="card-image-top m-3" src={Imaw} width="150" height="100"/>
        <h4 className="card-title card-link"style={{fontSize:"18px",fontWeight:"600"}}>MACHINE LEARNING </h4>
        <p>Machine learning is an application of AI that provides systems the ability to automatically learn and improve from experience without being explicitly programmed.</p>
      </div>
        </div>


        <div className="card p-3" style={{width:"20rem"}}>
        
        <div className="card-body">
       <img className="card-image-top m-3" src= {Imaf} width = "150" height="100" />
        <h4 className="card-title card-link"style={{fontSize:"18px",fontWeight:"600"}}> PYTHON/FULL STACK </h4>
  
        <p>Python is an interpreted, high-level, general-purpose programming language. Created by Guido van Rossum and first released in 1991, Python's design philosophy emphasizes code...</p>
      </div>
        </div></div>
        <div className="p-3 bg-light">
        <button className="border border-primary p-3 m-3"><Link to= "/Training" className="text-dark" >other trainings </Link></button>
        </div>
        <div>
      <div className="p-5 Image">
      <form>
        

        <div className="container m-3" style={{width:"500px",float:"centre"}}>
        <h1 className="text-light text-left m-3">Contact us</h1>   
        <input className="m-3 "placeholder="name" onChange={(event)=>{setName(event.target.value)}} />
    <input className="m-3 " placeholder="email" onChange={(event)=>{setEmail(event.target.value)}}/>
    <input className="m-3 "placeholder="mobilenumber"onChange={(event)=>{setMobile(event.target.value)}}/>
    <input className="m-3 "placeholder="city"onChange={(event)=>{setCity(event.target.value)}}/>

  

    {/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
    <input className="m-3"placeholder="intrested in"onChange={(event)=>{setIntrested(event.target.value)}}/>
    <button className="bg-primary m-3 p-3">SUBMIT</button></div></form></div>






        </div>

          
          
          
          
          
        </div>    

          )
    }
