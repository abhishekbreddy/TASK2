import React from 'react'
import Image from './q.jpg' 
import Image1 from './w.jpg'
import Image2 from './f.jpg'

export default class Courses extends React.Component{


 // state={
    //     apiData:[]
    // }
    
    
    // 
    

    // submit=()=> {
    //     alert("ok")
    //      Axios.post("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
    //             this.setState({
    //                 data:res.data
    //             })
    //             apiData.data =res.data
    //           console.log("apidata",apiData.data)
    //      },(err)=>{
    //        alert(err)
    //      })
    // }

  render(){
        return(<div><div className="card-group">
        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link">ARTIFICIAL INTELLIGENCE  </h4>
          <p>Artificial intelligence (AI) is an area of computer science that emphasizes the creation of intelligent machines that work and react like humans</p>
        </div>
          </div>
          
          <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
       <img className="card-image-top" src={{Image1}} />
        <h4 className="card-title card-link">MACHINE LEARNING </h4>
        <p>Machine learning is an application of AI that provides systems the ability to automatically learn and improve from experience without being explicitly programmed.</p>
      </div>
        </div>


        <div className="card" style={{width:"20rem"}}>
        
        <div className="card-body">
       <img className="card-image-top" src={{Image2}} />
        <h4 className="card-title card-link"> PYTHON/FULL STACK </h4>
        <p>Python is an interpreted, high-level, general-purpose programming language. Created by Guido van Rossum and first released in 1991, Python's design philosophy emphasizes code...</p>
      </div>
        </div></div>
        <button className="btn-primary">other trainings</button>

        <div>
        <div className="container m-3 p-3">
    <div className="container m-3">
        <input className="form-control m-3"placeholder="name"/>
    <input className="form-control m-3" placeholder="email"/>
    <input className="form-control m-3"placeholder="mobilenumber"/>
    <input className="form-control m-3"placeholder="city"/>

    {/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
    <input className="form-controlm-3"placeholder="intrested in"/>
    <button>submit</button></div></div>






        </div>

          
          
          
          
          
        </div>    
          )
    }
}