import React from 'react'
import { Link } from 'react-router-dom'
import Robo from './pics/robo.png'
import Tabs from 'react-bootstrap/Tabs'
import Tab from 'react-bootstrap/Tab'
import TabContainer from 'react-bootstrap/TabContainer'
import TabContent from 'react-bootstrap/TabContent'
import TabPane from 'react-bootstrap/TabPane'
import { Col, Row, Nav } from "react-bootstrap"
import './Robo.css'

export default class Robot extends React.Component{
    render() {
        return(<div className="row m-3">
  
 <div className="col-md-4 thumb mt-1">
                    <img src={Robo} alt="Artificial Intelligence Services in Hyderabad" style={{height: "390px"}}/>
                </div>
                <div className="col-sm-8 thumb">
                
                <Tab.Container id="left-tabs-example" defaultActiveKey="first" >
  <Row>
    <Col sm={4}>
      <Nav variant="tabs" className="flex-column">
        <Nav.Item className="border m-2" >
          <Nav.Link eventKey="first"  style={{height:"100%", color:"black"}}><li><i className="flaticon-story"></i></li><li>OUR STORY</li></Nav.Link>
        </Nav.Item>
        <Nav.Item className="border m-2">
          <Nav.Link eventKey="second"style={{height:"100%",color:"black"}}><li><i className="flaticon-shield"></i></li><li>Audit and Assurance</li></Nav.Link>
        </Nav.Item>
        <Nav.Item className="border m-2">
          <Nav.Link eventKey="three"style={{height:"100%",color:"black"}}><li><i className="flaticon-support"></i></li><li>24/7 LIVE SUPPORT</li></Nav.Link>
        </Nav.Item>

      </Nav>
    </Col>
    <Col sm={8}>
      <Tab.Content>
        <Tab.Pane eventKey="first">
          <h1 style={{fontSize:"30px",fontWeight:"600",textAlign:"left"}}>We Have Ample Experience In Standard Professional Services</h1>
   <div className="my-3 mr-3 text-left">       <p>
                                            The Feednet Solutions will drive perfection and initiative in India’s information, creation, and utilization of artificial intelligence (AI) to encourage financial development and improve the lives of Indians. 
                                        </p>
                                        <p className="text-left">
                                             Feednet Solutions endeavours to draw in the best worldwide ability concentrated on research brilliance in deep learning and machine learning. Our analysts and academic partners are a piece of a dynamic network of imaginative issue solvers, working across disciplines on both interests driven and connected research. 
                                        </p>  </div>                          

        </Tab.Pane>
        <Tab.Pane eventKey="second">
          <h1 style={{fontSize:"30px",fontWeight:"600",textAlign:"left"}}>We offer creative business</h1>
          <div className="my-3 mr-3 text-left">         <p>
											Innovation and creativity are in our DNA means creative solutions probably the most important factors when we talk about managing a new business or marketing it. Therefore we offer a wide range of creative &amp;  strategic branding applications, creative solutions services that could actually take your brand to places and elevate your results. More importantly, we know what we are doing. You are in safe hands. creative solution includes following
											</p>
                      <div class="table-responsive">
                      <table class="table"><tbody>
                                            <tr>
                                            <td><i class="fas fa-check-circle"></i> AI Solutions/Services </td>
                                            <td><i class="fas fa-check-circle"></i> Product Development </td>
                                            </tr>   <tr>     <td><i class="fas fa-check-circle"></i> R&amp;D </td>
                                            <td><i class="fas fa-check-circle"></i> Out Sourcing Employees </td>
                                            </tr><tr><td><i class="fas fa-check-circle"></i> Coworking Space</td>
                                            <td><i class="fas fa-check-circle"></i> Web Development </td>
                                        </tr></tbody></table></div></div>

        </Tab.Pane>
        <Tab.Pane eventKey="three">
          <h3 style={{fontSize:"30px",fontWeight:"600",textAlign:"left"}}>Ask your question to us</h3>
          <div className="my-3 mr-3 text-left">       <p>
                                            The Feednet Solutions will drive perfection and initiative in India’s information, creation, and utilization of artificial intelligence (AI) to encourage financial development and improve the lives of Indians. 
                                        </p>  
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <td>Email</td>
                                                        <td>post@feednetsolution.com</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Phone</td>
                                                        <td>+91 8639522961</td>
                                                    </tr>
                                                    <tr>
                                                        <td>PO Box</td>
                                                        <td>P no 65, Vittal Rao Nagar, Madhapur, Hyderabad, Telangana 500081.</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div> </div>                         

        </Tab.Pane>
      </Tab.Content>
    </Col>
  </Row>
</Tab.Container>

</div>

        </div>)
    }
}
