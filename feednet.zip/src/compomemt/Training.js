import React from 'react'

export default class extends React.Component{
    render(){
        return(<div><a href="http://feednetartificialintelligence.com/"/></div>)
    }
}