import Initialdata from "../Initialdata"








const Myreducer=(currentdata=Initialdata,action)=>{
switch(action.type){
    case'DATA':{
        currentdata={
            initdata:action.payload
        }
    }}
return currentdata



}
export default Myreducer