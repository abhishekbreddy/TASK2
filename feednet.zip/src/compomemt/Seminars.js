import React from 'react';
import {Link} from 'react-router-dom'
import {connect} from'react-redux'
import store from './Redux/Store'
import { ButtonToolbar } from 'react-bootstrap';
 class Seminars extends React.Component{
        constructor(props){
            super(props)
            this.state={
                userdata:this.props.storeData,
                name:"",
                mobileno:"",
                email:"",
                designation:""
        }
        
        }
        
handleChangeName=(event)=>{
       
        this.setState({
         name :event.target.value,
        
        })
      
    
     }
    
handleChangeMobileno=(event)=>{
       
        this.setState({
         mobileno :event.target.value,
        
        })
    }  
handleChangeEmail=(event)=>{
       
        this.setState({
         email:event.target.value,
        
        })
    }  
handleChangeDesignation=(event)=>{
       
        this.setState({
         designation :event.target.value,
        
        })
    }  
    
     





render(){
    return (<div> 

<div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>SERVICES DETAILS</h1></div>
<div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item"><Link TO="/corporate">TRAININGS</Link></li>
                        <li className="breadcrumb-item">SEMINARS</li>
                    </ul></div>






        
        <tr>
        <td style={{width:"70%"}}> 

        <div className ="container text-left p-5">
 <h1 className="text-primary"style={{fontSize:"35px",fontWeight:"600"}}>Free Seminars On Artificial Intelligence Every Saturday 2PM</h1>
 <li style ={{listStyle:"none"}}>Speaker : Sampath Kumar</li>
<li style ={{listStyle:"none"}} >Title : Artificial Intelligence</li>
<li style ={{listStyle:"none"}}>Location : P no 65, Vittal Rao Nagar, Madhapur Hyderabad, Telangana, 500081
Entry Free </li>

<br/>
<h1 style={{fontSize:"35px",fontWeight:"500"}}>We Provide Free Seminars on</h1>

<p className="fa-check">Artificial Intelligence :</p>

<p>Artificial Intelligence and Advanced Data Analytics reshape the world around us and the demand for Machine Learning and Deep Learning skills are continuously increasing. While the rapid emergence of Big Data has given fresh momentum to the development of new Deep Learning/AI techniques, further automating industrial processes using ML and AI plays a key role in ushering the Industry 4.0 revolution. These techniques are now used more and more to unlock the business values that used to be locked behind large volumes of data</p>

<h2 style={{fontSize:"20px",fontWeight:"600"}}>At Feednet Solutions, We Believe:</h2>

<p style={{fontSize:"25px",fontWeight:"600"}}>“Intelligence without ambition is a bird without wings"</p>

<p>So, to guide this intelligence in a right direction, we conduct free seminars and webinars on Artificial Intelligence
A seminar can be termed as the function of bringing together small groups for recurring meetings, focusing each time on some particular subject, in which everyone present is requested to participate. The idea behind this seminar system is to familiarize students more extensively with the current trends in AI and Machine Learning will be mentioned and we will discuss how Deep Learning actually works to enable cutting-edge AI technology performing at the highest level and also to allow them to interact with examples of the practical problems that always ocuur during our research work</p>

  <h2 className="text-primary"style={{fontSize:"20px",fontWeight:"600"}}>FREE SEMINARS ON ARTIFICIAL INTELLIGENCE</h2>
  <p>We also conduct Artificial Intelligence Webinars (a seminar attended through the Internet). These seminars can be called as</p>
  <h3
  style={{fontSize:"20px",fontWeight:"500"}}>“AN INTRODUCTION TO ARTIFICIAL INTELLIGENCE”</h3>
  <p>Here, students will get updated on current technologies and acquire knowledge on modules of:</p>
<li style={{listStyle:"none"}}>  Introduction to AI</li>
<li style={{listStyle:"none"}}>Basic Statistics </li>
<li style={{listStyle:"none"}}> Python</li>
<li style={{listStyle:'none'}}> Machine Learning</li>
<li style={{listStyle:'none'}}>Deep Learning</li>
<li style={{listStyle:"none"}}> Computer Vision</li>


<br/>
<div className="container-fluid " style={{backgroundColor:"whitesmoke"}}>
    {/* <div className="container p-3"style={{backgroundColor:"white"}}> */}
        <h1 className="text-dark m-5 text-center"style={{fontSize:"33px",fontWeight:"600"}}>Contact for seminars in  your College</h1>
        <div className="container" style={{width:"100%",float:"centre" }}>
   <div className="input-group" style={{width:"100%"}}> <input className="form-control m-3"placeholder="name" style={{width:"15%"}}  onChange={this.handleChangeName}/>
    <input type="number" className="form-control m-3"placeholder="mobilenumber"value={this.state.mobileno} onChange={this.handleChangeMobileno} /></div>
    <div className="input-group" style={{width:"100%"}}>
    <input type="email" className="form-control m-3" placeholder="email" value={this.state.email} onChange={this.handleChangeEmail}/></div>
    {/* <select className="form-control m-3"><option>Internship for Artificial Intelligence</option><option>Data Science with Python </option><option>Python full stack</option><option>AWS/Gcloud/Azure</option><option>other trainings</option></select> */}
   
    <div className="input-group" style={{width:"100%"}}>
   
    <input className="form-control m-3"placeholder="designation, hod,principal" value={this.state.designation} onChange={this.handleChangeDesignation}/></div>
    <button>submit</button></div></div>
    










</div>    
            
            
    </td>
    <td>
                <div className="card m-3">
                                  <div className="card-body p-3"><h1 className="text-dark text-left">SERVICES</h1>
                                   <li className="p-1 text-left"style={{listStyle:"none"}}>AI Solutions/Services</li><br/>
  </div>
                </div>

                <div className="card m-3">
                                   <div className="card-body p-3"><h1 className="text-dark">Need help</h1>
                      <li style={{listStyle:"none"}}>{this.state.userdata.address}</li>
                      <li style={{listStyle:"none"}}>{this.state.userdata.phoneno}</li>
                      <li style={{listStyle:"none"}}>{this.state.userdata.email}</li>
</div>
                </div>
                </td>




    </tr>












   






 </div>   )
}

}
export default connect((store)=>{
    return{
        storeData:store.Myreducer.initdata
    }
        
    })(Seminars)