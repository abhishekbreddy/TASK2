import React from 'react'
import { Link } from 'react-router-dom'
import Image from './25.jpg'
import Product from './Product'

export default class Research extends React.Component{
   
    constructor(props){
        super(props)
         this.state={
                address:' P no 65, Vittal Rao Nagar, Madhapur, Hyderabad, Telangana 500081',
                phoneno:'+91 8639522961',
                email:'info@feednetsolution.com'
            }
        }  

        
    render(){
        return(<div><table><tr>
            
            <td style={{width:'60%', height:'100%'}}>

             <img src ={{Image}} style={{width:'50%',height :'50%'}} />
             <div class="text-left">
            <h1>Research & Development</h1>
          <p>  Research and development R&D is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell. The goal most often is to add to the company's bottom line.
            
            <p>R&D is an important means for achieving future growth and maintaining a relevant product in the market. There is a misconception that R&D is the domain of high tech technology firms or the big pharmaceutical companies. In fact, most established consumer goods companies dedicate a significant part of their resources towards developing new versions of products or improving existing designs. However, where most other firms may only spend less than 5 percent of their revenue on research, industries such as pharmaceutical, software or high technology products need to spend significantly given the nature of their products.
            </p>
          <li>  KEY POINTS</li>
            
        <li>    R&D represents the activities companies undertake to innovate and introduce new products and services or to improve their existing offerings.</li>
         <li>   R&D allows a company to stay ahead of its competition.</li>
          <li> Companies in different sectors and industries conduct R&D; pharmaceuticals, semiconductor, and technology companies generally spend the most.</li></p></div></td>
            
            <td className ="p=3">
                <div className="card p-3 w-100">
                                   <div className="card-body p-3"><h1 className="text-dark">SERVICES</h1>
                                   <li className="p-1">AI Solutions/Services</li><br/>
                                   <li className="p-1">Product Development</li><br/>
                                   <li className="p-1">R&D</li><br/>
                                   <li className="p-1">Out Sourcing Employeesr</li><br/>
                                   <li className="p-1">Coworking Space</li><br/>
                                   <li className="p-1">Web Development</li>
</div>
                </div>

                <div className="card p-3 w-100">
                                   <div className="card-body p-3"><h1 className="text-dark">Need help</h1>
                                 
               <li>{this.state.address}</li>                   
   
<li>{this.state.phoneno}</li><li>{this.state.email}</li>
</div>
                </div>
                </td>
                </tr>
                </table></div>)
    }
}