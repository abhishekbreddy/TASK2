import React from 'react'
import { Link } from 'react-router-dom'
import Image from './pics/25.jpg'
import Product from './Product'
import store from'./Redux/Store'

export default class Research extends React.Component{
   
    constructor(props){
        super(props)
         this.state={
                address:' P no 65, Vittal Rao Nagar, Madhapur, Hyderabad, Telangana 500081',
                phoneno:'+91 8639522961',
                email:'info@feednetsolution.com',
                ai:"AI Solutions/Services",
                rd:"Research and Development",
                out:"outsourcing employees",
                cow:"Coworking Space",
                web:"web development",
                pro:"product development"
            }
        }  



        componentDidMount(){

          store.dispatch({
            type:'DATA',
            payload:this.state        })

            console.log(this.state)
        }

        
    render(){
        return(<div>
          
          <div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>SERVICES</h1></div>
<div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item"><Link TO="/Services">SERVICES</Link></li>
                        <li className="breadcrumb-item">R/D</li>
                    </ul></div>
          
          <table><tr>
            
            <td style={{width:'70%', height:'100%'}}>
            <div className="container m-4">
             <img src ={Image} style={{width:'500px',height :'300px'}} />
             <div class="text-left p-2 my-5">
            <h1 className="p-2"style={{fontSize:"30px",fontWeight:"600"}}>Research & Development</h1>
           
          <p>  Research and development R&D is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell. The goal most often is to add to the company's bottom line.
            <br/>
            <p> R&D is an important means for achieving future growth and maintaining a relevant product in the market. There is a misconception that R&D is the domain of high tech technology firms or the big pharmaceutical companies. In fact, most established consumer goods companies dedicate a significant part of their resources towards developing new versions of products or improving existing designs. However, where most other firms may only spend less than 5 percent of their revenue on research, industries such as pharmaceutical, software or high technology products need to spend significantly given the nature of their products.
            </p>
         <h5 className="text-dark" style={{fontSize:"15px", fontWeight:"600"}}>  KEY POINTS</h5>
            
        <li>    R&D represents the activities companies undertake to innovate and introduce new products and services or to improve their existing offerings.</li>
         <li>   R&D allows a company to stay ahead of its competition.</li>
          <li> Companies in different sectors and industries conduct R&D; pharmaceuticals, semiconductor, and technology companies generally spend the most.</li></p></div></div></td>
          
            <td className ="p-3">
                <div className="card m-3">
                                   <div className="card-body p-3 text-left"><h1 className="text-dark p-2"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>SERVICES</h1>
                              <div className="p-1">     <li className="p-1"style={{listStyle:"none"}}>{this.state.ai}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.pro}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.rd}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.out}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.cow}</li>
                                   <li className="p-1"style={{listStyle:"none"}}>{this.state.web}</li>
</div></div>
                </div>
                <div className="card m-3">
                                   <div className="card-body p-3"><h1 className="text-dark text-left p-1"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>Need help</h1>
                                 <div className="text-left p-3">
                                         <li style={{listStyle:"none"}}>
                                         <a href="https://www.google.com/maps/dir//feednetsolution/@17.4359666,78.3789042,14z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb91fe6992fceb:0x24fcbaa476a49d88!2m2!1d78.3844769!2d17.4447571" style={{color:"black"}}>
                         
                               
                                         <i class="fas fa-map-marker-alt  text-primary p-3"></i>&nbsp;{this.state.address}</a> </li>                   
   
<li  style={{listStyle:"none"}} ><i class="fas fa-phone  text-primary p-3"></i>{this.state.phoneno}</li><li style={{listStyle:"none"}}><i class="fas fa-envelope-open  text-primary p-3"></i>{this.state.email}</li>
</div></div>
                </div>
                </td>
                </tr> 
                </table></div>)
    }
}