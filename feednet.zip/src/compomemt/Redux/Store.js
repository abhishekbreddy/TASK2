import { createStore,combineReducers,applyMiddleware} from 'redux'
import Myreducer from '../Reducers/Reducer'
import reduxLogger from 'redux-logger'
const combinedReducer=combineReducers({Myreducer})
const store = createStore(combinedReducer,applyMiddleware(reduxLogger))
export default store