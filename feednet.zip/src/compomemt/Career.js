import React from 'react'
import Image from './carrer.jpg'

export default class Career extends React.Component{
    render(){
        return(<div>
<table><tr><td>
    
    <div className="card">
<img src={Image}/>
    </div>
    
    
    
    </td>
    <td><p className="text-left p-3"><h1>Join Our Team</h1>
<p>The Feednet Solutions will drive perfection and initiative in India’s information, creation, and utilization of artificial intelligence (AI) to encourage financial development and improve the lives of Indians.</p>

<p>Feednet Solutions endeavours to draw in the best worldwide ability concentrated on research brilliance in deep learning and machine learning. Our analysts and academic partners are a piece of a dynamic network of imaginative issue solvers, working across disciplines on both interests driven and connected research.</p></p></td>
    
    </tr></table>
<div className="bg-light">
<h1>YOUR CAREER STARTS HERE </h1>

<div className="card-group">
        <div className="card p-3" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
         <p>
          <h4 className="card-title card-link"> UI/UX developer </h4>
          Openings(2)</p>

          
          </div>
          
          
          
          
       </div>

       <div className="card p-3" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link">Devops  </h4>
          <p>Openings(3)</p>

        
          </div>
          
          
          
          
       </div>


       <div className="card p-3" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> Machine Learning  </h4>
          <p>openings(7)</p>
        
          </div>
          
          
          
          
       </div></div>
       <div className="card-group">
       <div className="card p-3" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> Business Development Executive </h4>
          <p>opening(7)</p>
        
          </div>
          
          
          
          
       </div>

       <div className="card p-3" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> Sales Officers </h4>
          <p>openings(4)</p>
        
          </div>
          
          
          
          
       </div>
       <div className="card p-3" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="card-image-top" src={{Image}} />
          <h4 className="card-title card-link"> Artificial Intelligence </h4>
          <p>
              
              
         Openings(5)</p>
        
          </div></div></div><div className="m-5">
          
          <button>Apply here</button></div>
          
          
          
          </div></div>
)

        }}












