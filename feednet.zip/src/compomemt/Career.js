import React from 'react'
import Carier from './pics/carrer.jpg'
import Image from './pics/images.jpg'
import Image1 from './pics/UI.png'
import Image2 from './pics/devops.jpg'
import Image3 from './pics/ML.jpg'
import Image4 from './pics/Inn.jpg'
import Image5 from './pics/desktop.jpg'
import './Carrier.css'
import {Link }from 'react-router-dom'

export default class Career extends React.Component{
    render(){
        return(<div><div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>CAREERS</h1></div>

<div><ul className="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i className="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item">Carrier</li>
                    </ul></div>

                    <div className="text-center">
                        <h2>Careers at Feednet</h2>
                        <p className="text-primary" style={{fontWeight:"bold"}}>__ _____ __</p>
                        
                    </div>
                
                            



<table className="p-5"><tr><td style={{width:"35%"}}><div className="container"style={{width:"100%"}} ><div className="card">
<img  src={Carier} style={{borderRadius:"10px"}} width="100%" padding="5px"/></div>
</div>  
    
    
    
    
    </td>
    <td><p className="text-left px-3 pb-5"><h2 style={{fontSize:"30px",fontWeight:"400",color:'black'}}>Join Our Team</h2>
    
<p >The Feednet Solutions will drive perfection and initiative in India’s information, creation, and utilization of artificial intelligence (AI) to encourage financial development and improve the lives of Indians.</p>

<p>Feednet Solutions endeavours to draw in the best worldwide ability concentrated on research brilliance in deep learning and machine learning. Our analysts and academic partners are a piece of a dynamic network of imaginative issue solvers, working across disciplines on both interests driven and connected research.</p></p></td>
    
    </tr></table>
<div className="bg-light p-5" >
<h1  style={{fontSize:"30px",fontWeight:"600"}}>YOUR CAREER STARTS HERE </h1>
<p className="text-primary">__ _____ __</p>
 <div className="card-group">
        <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="image_img m-2" src={Image1} width="100%" height="50%"/>

         <div className="image_overlay">
             <h1 className="devops text-centre" style={{fontSize:"16px"}}>UI/UX developer</h1>
         </div>
         <p>
          <h4 className="card-title card-link"> UI/UX developer </h4>
          Openings(2)</p>

          
          </div>
          
          
          
          
       </div>

       <div className="card " style={{width:"20rem"}}>
        
          <div className="card-body">
            
         <img className="image_img" src={Image2}  width="100%" height="50%"/>
         <div className="image_overlay">
             <h1 className="devops text-centre" style={{fontSize:"16px",fontWeight:"700",left:"25%"}}> Devops</h1>
         </div>
          <h4 className="card-title card-link">Devops  </h4>
          <p>Openings(3)</p>

        
          </div>
          
          
          
          
       </div>


       <div className="card" style={{width:"20rem",padding:"0px"}}>
        
          <div className="card-body">
         <img className="image_img" src={Image3} width="100%" height="50%" />
         <div className="image_overlay">
             <h1 className="devops text-centre" style={{fontSize:"16px"}}>Machine Learning</h1>
         </div>
          <h4 className="card-title card-link"> Machine Learning  </h4>
          <p>openings(7)</p>
        
          </div>
          
          
          
          
       </div>
       
       <div className="card" style={{width:"20rem",padding:"0px"}}>
        
          <div className="card-body">
         <img className="image_img" src={Image4 }  width="100%" height="50%"/>
         <div className="image_overlay">
             <h1 className="devops text-centre" style={{fontSize:"16px"}}>Business Development Executive</h1>
         </div>
          <h4 className="card-title card-link"> Business Development Executive </h4>
          <p>opening(7)</p>
        
          </div></div>
         </div> 
          
         
   
<div className="card-group"style={{width:"50%"}}>
       <div className="card" style={{width:"20rem"}}>
        
          <div className="card-body">
         <img className="image_img" src={Image5} width="100%" height="50%"/>
         <div className="image_overlay">
             <h1 className="devops text-centre" style={{fontSize:"16px"}}>Sales Officers</h1>
         </div>
         
         <h4 className="card-title card-link">sales Officers </h4>
          <p>opening(4)</p>
          </div>
          
          
          
          
       </div>
       <div className="card" style={{width:"20rem"}}>
        

          <div className="card-body">
         <img className="Image_img" src={Image} width="100%" height="50%"/>
         <div className="image_overlay">
             <h1 className="devops text-centre" style={{fontSize:"16px"}}>Artificial Intelligence</h1>
         </div>
          <h4 className="card-title card-link"> Artificial Intelligence </h4>
          <p>
              
              
         Openings(5)</p>
        
          </div></div></div><div className="m-5">
          
          <button className="border border-primary p-3 pl-5 pr-5"><Link to ="/jobapply"><p className="text-dark">Apply here</p></Link></button></div>
          
          
          </div>  
          </div>
)

        }}












