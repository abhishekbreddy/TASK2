import React from 'react'
import { Link } from 'react-router-dom'
import Image from './pics/22.jpg'
import Reaserch from "./R&D";
import {connect} from'react-redux'
import store from './Redux/Store';
import './Product.css'


class Product extends React.Component {
constructor(props){
    super(props)
    this.state={
        userdata:this.props.storeData
    }
}
  
   render(){

   
    




        return(<div>
            <div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>SERVICES</h1></div>
<div><ul class="breadcrumb text-center float-ceter">
                        <li className="breadcrumb-item"><Link to="/"><i className="fas fa-home" style={{fontSize:"2px"}}></i> Home</Link></li>
        

                        <li className="breadcrumb-item"><Link TO="/Services">SERVICES</Link></li>
                        <li className="breadcrumb-item">PRODUCT</li>
                    </ul></div>
            
            
            
            
            
            
            
            
            <table><tr>
            
            <td style={{width:'70%', height:'100%'}}>
            <div className="container m-4">
             <img src ={Image} width='500px'height ='300px' />
             <div class="text-left p-2 my-5">
            <h1 className="p-2"style={{fontSize:"30px",fontWeight:"600"}}>Product Development</h1>
          <p> Product development is the creation of a new or different product that offers innovative new benefits to the end user. This includes both the creation of an entirely new product and modifications to an existing product. These changes or new introductions may be targeting a newly defined customer requirement or a niche category in the market.</p>

<p>A product can be defined as a collection of benefits that can be either tangible such as a physical item or intangible such as a service or experience. The new product development process involves two simultaneous activity paths. One of these focuses on extensive market research and analysis while the other deals with generating ideas, design of the product and detail engineering.</p>

<p>New product development is the first stage in the product life cycle management process, the strategic process that is used to manage products and market share. An effective product development process helps a company to:</p>

<p>Grow through the creation of new business opportunities.
Boost profitability for stakeholders.
Increase customer satisfaction through better products meeting specific needs.</p></div></div></td>
            
            <td className ="p-3">
                <div className="card  m-3">
                                  <div className="card-body p-3 text-left"><h1 className="text-dark p-2"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>SERVICES</h1>
                            <div className="p-1">       <li style={{listStyle:"none"}}>AI Solutions/Services</li><br/>
                                   <li style={{listStyle:"none"}}>Product Development</li><br/>
                                   <li style={{listStyle:"none"}}>R&D</li><br/>
                                   <li style={{listStyle:"none"}}>Out Sourcing Employeesr</li><br/>
                                   <li style={{listStyle:"none"}}>Coworking Space</li><br/>
                                   <li style={{listStyle:"none"}}>Web Development</li>
</div>
                </div></div>

                <div className="card m-3">
                                   <div className="card-body p-3"><h1 className="text-dark text-left p-1"style={{fontSize:"20px",fonttype:"bold",borderBottom: "2px solid gray"}}>Need help</h1>
                                   <div className="text-left p-3">
                                         <li style={{listStyle:"none"}}>
                                         <a href="https://www.google.com/maps/dir//feednetsolution/@17.4359666,78.3789042,14z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb91fe6992fceb:0x24fcbaa476a49d88!2m2!1d78.3844769!2d17.4447571" style={{color:"black"}}>
                         
                               
                                         <i class="fas fa-map-marker-alt   text-primary p-3" ></i>&nbsp;{this.state.userdata.address}</a> </li>                   
   
<li  style={{listStyle:"none"}} ><i class="fas fa-phone  text-primary p-3"></i>{this.state.userdata.phoneno}</li><li style={{listStyle:"none"}}><i class="fas fa-envelope-open  text-primary p-3"></i>{this.state.userdata.email}</li>
</div>
 
                      
</div>
                </div>
                </td>
                </tr>
                </table></div>)
    }
}

export default connect((store)=>{
return{
    storeData:store.Myreducer.initdata
}
    
})(Product)
