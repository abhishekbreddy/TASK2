import React from 'react'
import { Link } from 'react-router-dom'
import Image from './22.jpg'
import Reaserch from "./R&D";


export default class product extends React.Component {

  
   render(){

   
    




        return(<div><table><tr>
            
            <td style={{width:'60%', height:'100%'}}>

             <img src ={{Image}} style={{width:'50%',height :'50%'}} />
             <div class="text-left">
            <h1>Product Development</h1>
          <p> Product development is the creation of a new or different product that offers innovative new benefits to the end user. This includes both the creation of an entirely new product and modifications to an existing product. These changes or new introductions may be targeting a newly defined customer requirement or a niche category in the market.</p>

<p>A product can be defined as a collection of benefits that can be either tangible such as a physical item or intangible such as a service or experience. The new product development process involves two simultaneous activity paths. One of these focuses on extensive market research and analysis while the other deals with generating ideas, design of the product and detail engineering.</p>

<p>New product development is the first stage in the product life cycle management process, the strategic process that is used to manage products and market share. An effective product development process helps a company to:</p>

<p>Grow through the creation of new business opportunities.
Boost profitability for stakeholders.
Increase customer satisfaction through better products meeting specific needs.</p></div></td>
            
            <td className ="p=3">
                <div className="card  w-100">
                                  <div className="card-body p-3"><h1 className="text-dark">SERVICES</h1>
                                   <li className="p-1">AI Solutions/Services</li><br/>
                                   <li className="p-1">Product Development</li><br/>
                                   <li className="p-1">R&D</li><br/>
                                   <li className="p-1">Out Sourcing Employeesr</li><br/>
                                   <li className="p-1">Coworking Space</li><br/>
                                   <li className="p-1">Web Development</li>
</div>
                </div>

                <div className="card p-3 w-100">
                                   <div className="card-body p-3"><h1 className="text-dark">Need help</h1>
       <li>{this.props.state}</li>
       <li>{this.props.phoneno}</li>                          
 
</div>
                </div>
                </td>
                </tr>
                </table></div>)
    }
}