import React from 'react'
import './Blog.css'

 import Img from './pics/3.jpg'
 import Img1 from './pics/11.jpg'
 import Img2 from './pics/12.jpg'
 import Img3 from './pics/13.jpg'
 import Img4 from './pics/andriod-ios.png'
 import {Link} from 'react-router-dom'

export default class Blog extends React.Component{
    render(){
    return(<div><div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>BLOG</h1></div>
<div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item">Blog</li>
                    </ul></div>


        <div className="container w-1">
            <h2 className=" text-center"style={{fontWeight:"600",color: "#0cb8b6"}}>What strategies a new business needs to get successful?</h2>
            <p className="text-muted text-left">There are plenty of businesses evolving each day in all the different categories. And do you think it is easy to defeat all of them stand still in the competition? Maybe or maybe not, it all depends on what strategies you are using to make your business a successful one.<br/>
There are many strategies, but few are proven to be worthy off. It is beneficial to know these 4 strategies to develop your company along with standing over your competitors.</p>
      <div className="container  text-left " style={{marginLeft:"180px", marginLeft:"180px",paddingRight:"180px"}}>
        <div className="text-content">
      <h2  className=" text-left" style={{fontFamily:"sans-serif",color:"#0cb8b6"}}>
          
         <i className="fas fa-angle-double-right p-1"></i> 
          
          Artificial Intelligence</h2>
      <p>Artificial intelligence in short known to be AI, It is the best way to know your audience and filter them according to your requirement.</p>  
      <h4 style={{fontSize:"19px",fontWeight:"300"}}>Ways Artificial Intelligence can transform Your Business in the Future</h4>
       <h5>1. Customer Relationship Management</h5>  
       <p>The algorithm gets more proficient with human interaction with every new exposure. In the time when customer service interactions require human aide( including calls, emails, online chats, etc.), Artificial intelligence can help radicalize customer relationship management. Artificial intelligence can analyze data from previous communication, process, problem solve, and accurately respond to customer inquiries. Using automated chat software will also help give better, more dynamic and personalized answers, building stronger customer relations, whilst analyzing and predicting insights that can be used to recommend and personalize services</p> 
        <h5>2. Data Mining</h5>  
        <p>Artificial intelligence can help sort through a gigantic amount of data and narrow down results by analyzing data and problem tasks. And then aid in sorting, sifting and solving of the said tasks. By utilizing various features and algorithms such as biometric and psychometric analysis, exploratory analysis and integrated interpretation, AI can immensely help in mining the data necessary, and interpreting insights and results</p>
        <h5>3. Informed Decision Making</h5>
         <p>
         AI used in business and marketing are proficient in analyzing the data input and learning from them for future references. The potential to learn and improve with every data received is a great advantage, as it helps build personalized, profitable campaigns for both the consumer and your business. AI can help to take informed decisions by integrating analysis by customers, service representatives and consultants, and can potentially lead to automated decision-making.  
         </p>
           <h5>4.Improving Security</h5> 
        <p className="text-muted">Artificial intelligence can be an efficient tool in detecting fraud and identifying fraudulent activity. Recent advanced AI can be regularly updated to self scrutinize and identify behaviors and patterns consistent with fraud. Hence, AI becomes indispensable in protecting valuable consumer data; hence building the customer’s trust and there by increasing business value</p>
        <h5>5. Streamlining of the Manufactured Products</h5>
<p className="text-muted"> Artificial intelligence can be easily incorporated in the manufacturing units; as they can improve and automate the manufacturing process. Smart technology such as driverless warehouse carts, automated inventories and AI equipped machines can lead to automation of the manual aspects of manufacturing; thereby increasing agility and accuracy

 </p>
 <img src={Img} class="rounded mx-auto d-block p-3" style={{height :'300px'}}/>
 <div>
 <div><h2 className="text-left text-primary"style={{fontFamily:"sans-serif",color:"#0cb8b6"}}><i className="fas fa-angle-double-right p-1"></i>Web Designing</h2><p>
 Web Designing is what everyone going after and how does it make any difference? You are wrong if you think it is not a profitable strategy. There might be many websites on Google these days, it depends on how different your website looks. The websites are of two kinds which are Static and Dynamic, you can have your own style based on the business. If you are a product selling company, then having a website could be more useful, you will get to display all your products to the customers</p>
 <img src ={Img1} class="rounded mx-auto d-block p-3" style={{height :'300px'}}/>
 </div>
 <div>
     <h2 className="text-left text-primary "style={{fontFamily:"sans-serif",color:"#0cb8b6"}}><i className="fas fa-angle-double-right p-1"></i>Ad Shoots</h2><p>
 We always think about different ways to promote the product and most of them ignore ad shoots. And this is because of an assumption that ad shoots are a costly culture, but you forget small logic over here. Yes, this might be a costly affair but you can earn more than what you have invested within no time. An Ad shoot will give you a brand identity. It is not about the models, costumes or anything else it will give you an idea about your brand to the people. It is one of speed and organic way to get the audience’s attention within no time.
 </p>
 <img src ={Img2} class="rounded mx-auto d-block p-3" style={{height :'300px'}}/></div>
 <div>
 <h2 className="text-left text-primary"style={{fontFamily:"sans-serif",color: "#0cb8b6"}}><i className="fas fa-angle-double-right p-1"></i>Digital Marketing</h2>
 <p>
     Digital Marketing is one word that we have learnt so much about in certain months. And there have been many companies providing these services because of its demand in the competition. There are many categories within the digital marketing program, such as SEO, SMO, PPC and many more. These all things will ensure to evolve your brand name. SEO will help your website rank on Google’s 1st page, SMO does help you with promoting your company on social media platforms. And so the other categories are for making a successful business for you
 </p>
 <img src= {Img3} class="rounded mx-auto d-block p-3" height ='300px'/>

 </div><div>
     <h2 className=" text-left text-primary"style={{fontFamily:"sans-serif",color: "#0cb8b6"}}><i className="fas fa-angle-double-right p-1"></i>Android/IOS Deveopment</h2>
     <p>
     We at Feednet solutions make powerful mobile appplication(Android and IOS) for your business.Recent studies shows that a business with mobile applicaton will help their customers to have good relationship and have more trust and trasancations.
<br/>
 iOS (formerly iPhone OS) is a mobile operating system created and developed by Apple Inc. exclusively for its hardware. It is the operating system that presently powers many of the company's mobile devices, including the iPhone, and iPod Touch; it also powered the iPad prior to the introduction of iPadOS in 2019. It is the second most popular mobile operating system globally after Android. It is the basis for other operating systems made by Apple Inc, like iPadOS, tvOS, and watchOS.
<br/>
 Android software development is the process by which new applications are created for devices running the Android operating system. Google states that "Android apps can be written using Kotlin, Java, and C++ languages" using the Android software development kit (SDK), while using other languages is also possible. All non-JVM languages, such as Go, JavaScript, C, C++ or assembly, need the help of JVM language code, that may be supplied by tools, likely with restricted API support. Some programming languages and tools allow cross-platform app support (i.e. for both Android and iOS). Third party tools, development environments, and language support have also continued to evolve and expand since the initial SDK was released in 2008. In addition, with major business entities like Walmart, Amazon, and Bank of America eyeing to engage and sell through mobiles, mobile application development is witnessing a transformation. The official Android app distribution mechanism to end users is Google Play; it also allows staged gradual app release, as well as distribution of pre-release app versions to testers.
 </p>
 <img src={Img4} className="rounded mx-auto d-block p-3"  height="300"/>
 </div>
 </div></div></div></div></div>)}

            
            
            



        

}