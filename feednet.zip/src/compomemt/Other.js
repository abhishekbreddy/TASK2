import React from 'react'
import { Link } from 'react-router-dom'
import Image from './pics/10.jpg'
import Image1 from './pics/6.jpg'
import Image2 from './pics/a.jpg'
import Image3 from './pics/b.jpg'
import Image4 from './pics/c.jpg' 
import Image5 from './pics/d.jpg'
import Image6 from './pics/e.jpg'

export default class OtherServices extends React.Component{

render(){
  return(<div>


<div className="blog , container-fluid text-light"><h1 style={{padding:"100px"}}>OUR SERVICES</h1></div>
<div><ul class="breadcrumb text-center">
                        <li className="breadcrumb-item"><Link to="/"><i class="fas fa-home"></i> Home</Link></li>
                        

                        <li className="breadcrumb-item">SERVICES</li>
                       
                    </ul></div>










<div>
  <br></br><br></br><br></br>
    <div className="card-group">
<div className="card" style={{width:"10px"}}>

  <div className="card-body">
 <img className="card-image-top m-3" src={Image} width ="40%" />
  <h4 className="card-title card-link m-3"style={{fontSize:"18px",fontWeight:"600"}}> INTERNET OF THINGS </h4>
  <p>The Internet of Things (IoT) is a system of interrelated computing devices, mechanical and digital machines, objects, animals or people that are provided with unique identifiers</p>

  </div>
  
  
  
  
  </div> 
  <div className="card" style={{width:"20rem"}}>

<div className="card-body">
<img className="card-image-top m-1" src={Image1} width ="35%"/>
<h4 className="card-title card-link m-3"style={{fontSize:"18px",fontWeight:"600"}}> WEB DEVELOPMENT </h4>
<p>According to recent business statistics when it comes to hiring a web design or web development professionals, companies are becoming incredibly choosy....</p>

</div>




</div> 

<div className="card" style={{width:"20rem"}}>

<div className="card-body">
<img className="card-image-top m-3" src={Image2} width="40%" />
<h4 className="card-title card-link m-3"style={{fontSize:"18px",fontWeight:"600"}}> ANDROID/IOS DEVELOPMENT </h4>
<p>Android is a mobile operating system developed by Google. It is based on a modified version of the Linux kernel and other open source software
</p></div></div></div>
<div className="card-group">
<div className="card" style={{width:"20rem"}}>

<div className="card-body">
<img className="card-image-top m-2" src={Image3}  width="40%"/>
<h4 className="card-title card-link m-3"style={{fontSize:"18px",fontWeight:"600"}}> DIGITAL MARKETING </h4>
<p>Digital Marketing is the branch of marketing through which one can do the marketing of products or services using digital technologies like facebook, twitter, instagram etc.
</p></div></div>

<div className="card" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top m-3" src={Image4} width="40%"/>
<h4 className="card-title card-link m-3"style={{fontSize:"18px",fontWeight:"600"}}>OUT SOURCING EMPLOYEES </h4>
<p>Outsourcing Employment is easiest and fastest way to hire employees in countries where you do not have a legal entity or where you are not allowed to hire people for any reason.
</p></div></div>


<div className="card" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top m-2" src={Image5} width="40%" />
<h4 className="card-title card-link m-3"style={{fontSize:"18px",fontWeight:"600"}}>COWORKING SPACE </h4>
<p>Feednet Solution is Situated in the prime business area of Madhapur, and is additionally near Hi-Tech City, with all significant IT organizations situated inside a 2 km span.
</p></div></div></div>

<div className="card" style={{width:"34%"}}>
<div className="card-body">
<img className="card-image-top m-2" src={Image6} width="40%"/>
<h4 className="card-title card-link m-3"style={{fontSize:"18px",fontWeight:"600"}}> AD AGENCY</h4>
<p>An advertising agency, often referred to as a creative agency or an ad agency, is a business dedicated to creating, planning, and handling advertising and sometimes other forms..
</p></div></div>









            
            
           </div>



  </div>)
}


}  