import React from 'react'
import Image from './1.jpg'
import Image1 from './2.png'
import Image2 from './5.jpg'
import Image3 from './4.png'
import Image4 from './3.jpg'
import Image5 from './7.jpg'
import Image6 from './8.jpg'
import Research from './R&D'
import Image7 from './Reaserch.jpg'
import Image8 from './ProducT.jpg'
import { Link, Route, Router } from 'react-router-dom'
export default class Home extends React.Component{
    render(){
        return(<div>

         <div className="card-group ">
<div className="card m-3" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top" src={{Image7}} />
<h4 className="card-title card-link"> AD AGENCY</h4>
<p>An advertising agency, often referred to as a creative agency or an ad agency, is a business dedicated to creating, planning, and handling advertising and sometimes other forms..
</p></div></div>


<div className="card m-3" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top" src={{Image8}} ></img>
<h4 className="card-title "> AD AGENCY</h4>
<p>An advertising agency, often referred to as a creative agency or an ad agency, is a business dedicated to creating, planning, and handling advertising and sometimes other forms..
</p></div></div>

<div className="card m-3" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top" src={{Image4}} />
<h4 className="card-title card-link"> AD AGENCY</h4>
<p>An advertising agency, often referred to as a creative agency or an ad agency, is a business dedicated to creating, planning, and handling advertising and sometimes other forms..
</p></div></div>







</div>   
 











           
            
            
            
            
            
            
            
            
            
            
            
            
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
     <div class="carousel-inner"><div class="carousel-item active"><div className="card">
            <table><tr><td style={{width:'50%'}} ><img src={Image4} style={{width:'100%'}}/>
            </td><td ><div class="text">
            <h2>What we do</h2>
            <h4>Make our Customers Happy</h4>
            <p>
                                We’re a team of scientists, engineers, machine learning experts and more, working together to advance the state of the art in artificial intelligence. We use our technologies for widespread public benefit and scientific discovery, and collaborate with others on critical challenges, ensuring safety and ethics are the highest priority.
								</p> 
            <blockquote>
                                We always stay with our clients and respect their business. We deliver 100% and provide instant response.
                            </blockquote>
                
                <ul className="text-left">
                                <li className="fa fa-check">AI Solutions/Services</li><br/>
                                <li className="fa fa-check">Product Development</li><br/>
                                <li className="fa fa-check">R&D </li><br/>
                                <li className="fa fa-check">Out Sourcing Employees</li><br/>
								<li className="fa fa-check">Coworking Space</li><br/>
								<li className="fa fa-check">Web Development</li>
                            </ul></div></td></tr></table></div></div>


                            <div class="carousel-item  "><div className="card">
            <table><tr><td style={{width:'50%'}} ><img src={Image5} style={{width:'100%'}}/>
            </td><td ><div class="text">
            <h2>Our Mission</h2>
            <h4>To Redefine your Career</h4>
            <p>
                                We believe that the future will belong to a beautiful amalgamation of what Machines and Humans can achieve together. The way how machines respond to challenges when equipped with human like intelligence. 
								</p> 
                                <blockquote>
                                We always stay with our clients and respect their business. We deliver 100% and provide instant response.
                            </blockquote>
                
                            <ul className="text-left fa fa-check">
                                <li>AI Solutions/Services</li>
                                <li>Product Development</li>
                                <li>R&D </li>
                                <li>Out Sourcing Employees</li>
								<li>Coworking Space</li>
								<li>Web Development</li>
                            </ul></div></td></tr></table></div></div></div>




                            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="false"></span>
    <span class="visually-hidden">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="false"></span>
    <span class="visually-hidden">Next</span>
  </a>








                           </div>
                           
                           
                            
                            
                            
                            
                            






            <h1 className="text-centre text-dark">Ourpartners</h1>
        <table >
            <tr>
                <td style={{padding:"50px"}}>
                    <img src={Image}/> 
                    </td> 
                    <td style={{padding:"50px"}}>
                        <img src={Image1}/> 
                        </td> 
                        <td style={{padding:"50px"}}>
                            <img src={Image2}/>
                              </td> 
                              <td style={{padding:"50px"}}>
                                  <img src={Image3}/> 
                                  </td>
                                  </tr>
                                  </table></div>
                                  )
    }
}