import React from 'react'
import Image from './pics/1.jpg'
import Image1 from './pics/2.png'
import Image2 from './pics/5.jpg'
import Image3 from './pics/4.png'
import Image4 from './pics/3.jpg'
import Image5 from './pics/7.jpg'
import Image6 from './pics/8.jpg'
import Research from './R&D'
import Image7 from './pics/Reaserch.jpg'
import Image8 from './pics/ProducT.jpg'
import Services from './pics/Services.jpg'
import Robot from './pics/Robot.jpg'
import Lamp from './pics/LAMP.jpg'
import { Link, Route, Router } from 'react-router-dom'
import {Carousel} from 'react-bootstrap'
import './Home.css'
import Robo from './Robo'

export default class Home extends React.Component{
    render(){
        return(<div><div>

<Carousel>
  <Carousel.Item >
  <img
       className="d-block w-100 anim"
      src={Services}
      alt="Third slide"
    />
    <Carousel.Caption>
    
      
       <p>START WITH US AND GROW YOUR BUSINESS</p> 
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100  anim"
      src={Robot}
      alt="Third slide"
    />
    <Carousel.Caption>
      <h3>Search a businessman</h3>
      <p>FOR MAKING A PLAN IN YOUR BUSINESS</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100 anim"
      src={Lamp}
      alt="Third slide"
    />
    <Carousel.Caption>
      <h3>Creating more value</h3>
      <p>FIND VALUE AND BUILD CONFIDENCE.</p>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel></div>

<Robo/>

<div className="Container-fluid p-5"style={{background: "linear-gradient(180deg, whitesmoke 50%,#002147 50%)"}} >

      <h1 style={{fontSize:"30px",fontWeight:"700"}}>OUR SERVICES</h1>
      <p className="text-primary" style={{fontSize:"30px"}}>__ ___ __</p>
      
               <div className="card-group ">
<div className="card m-3" style={{width:"20rem"}} >
<div className="card-body">
<img className="card-image-top" src={Image7} width="100%"/>
<button className="button" style={{borderRadius:"35px",backgroundColor:"lightblue"}}> <Link to="/R&D"className="text-dark" >Read me </Link></button>
<h4 className="card-title "> Research & Development </h4>
<p className="text-muted"> R&D – is the process by which a company works to obtain new knowledge that it might use to create new technology, products, services, or systems that it will either use or sell.</p></div></div>


<div className="card m-3" style={{width:"20rem"}}>
<div className="card-body">
<img className="card-image-top" src= { Image8 } width="100%"/>

<button  className="button" style={{borderRadius:"35px",backgroundColor:"lightblue"}}> <Link to="/product"className="text-dark" >Read me </Link></button>
<h4 className="card-title "><Link to ="/product"className="text-dark">Product Development</Link></h4>
<p className="text-muted">Product development is a creation of new or different product that offers benefits to the end user includes both creation of an new product and modifications to an existing product
</p></div></div>

<div className="card m-3" style={{width:"20rem"}}>
<div className="card-body"><div>
<img className="card-image-top" src= {Image4} width="100%"/>

<button  className="button" style={{borderRadius:"35px",backgroundColor:"lightblue"}}> <Link to="/AI"className="text-dark">Read me </Link></button>

</div>
<h4 className="card-title"> AI SOLUTIONS & SERVICES </h4>
<p className="text-muted">
Today Machine Learning and Artificial Intelligence is penetrating every side of the business, from deploying Chatbots to AI-driven platforms.</p>
</div>

</div>

</div> 
</div>




<div >
<Carousel>
  <Carousel.Item>
            <table><tr><td style={{width:'50%'}} ><img src={Image4} style={{width:'100%'}}/>
            </td><td ><div className="text  text-left p-5">
            <h2 style={{fontSize:"33px",fontWeight:"700"}}>What we do</h2>
            <h4  className="text-primary py-3" style={{textDecoration:"underline"}}>Make our Customers Happy</h4>
            <p>
                                We’re a team of scientists, engineers, machine learning experts and more, working together to advance the state of the art in artificial intelligence. We use our technologies for widespread public benefit and scientific discovery, and collaborate with others on critical challenges, ensuring safety and ethics are the highest priority.
								</p> 
            <blockquote className="p-3" style={{borderLeft:"5px solid gray",fontStyle:"italic"}}>
                                We always stay with our clients and respect their business. We deliver 100% and provide instant response.
                            </blockquote>
                
                <ul className="text-left">
                                <li className=" p-1"style={{borderBottom:"5px solid lightblue",width : "100%",listStyle:"none"}}><i className="fa fa-check"></i> AI Solutions/Services </li><br/>
                                <li className=" p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Product Development</li><br/>
                                <li className=" p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> R&D </li><br/>
                                <li className="p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Out Sourcing Employees</li><br/>
								<li className=" p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Coworking Space</li><br/>
								<li className="p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Web Development</li>
                            </ul></div></td></tr></table></Carousel.Item>


                            <Carousel.Item >
            <table><tr><td style={{width:'50%'}} ><img src={Image5} style={{width:'100%'}}/>
            </td><td ><div className="text-left p-3">
            <h2 style={{fontSize:"33px",fontWeight:"700"}}>Our Mission</h2>
            <h4 className="text-primary">To Redefine your Career</h4>
            <p>
                                We believe that the future will belong to a beautiful amalgamation of what Machines and Humans can achieve together. The way how machines respond to challenges when equipped with human like intelligence. 
								</p> 
                                <blockquote  className="p-3"style={{borderLeft:"5px solid gray",fontStyle:"italic"}}>
                                We always stay with our clients and respect their business. We deliver 100% and provide instant response.
                            </blockquote>
                
                            <ul className="text-left">
                                <li className="p-1" style={{borderBottom:"5px solid lightblue",width : "100%",listStyle:"none"}}><i className="fa fa-check"></i>AI Solutions/Services</li><br/>
                                <li className="p-1"style={{borderBottom:"5px solid lightblue",width : "100%",listStyle:"none"}}><i className="fa fa-check"></i>Product Development</li><br/>
                                <li className="p-1"style={{borderBottom:"5px solid lightblue",width : "100%",listStyle:"none"}}><i className="fa fa-check"></i>R&D </li><br/>
                                <li className=" p-1"style={{borderBottom:"5px solid lightblue",width : "100%",listStyle:"none"}}><i className="fa fa-check"></i>Out Sourcing Employees</li><br/>
								<li className=" p-1"style={{borderBottom:"5px solid lightblue",width : "100%",listStyle:"none"}}><i className="fa fa-check"></i>Coworking Space</li><br/>
								<li className="p-1"style={{borderBottom:"5px solid lightblue",width : "100%",listStyle:"none"}}><i className="fa fa-check"></i>Web Development</li>
                            </ul></div></td></tr></table></Carousel.Item>
                        
                            <Carousel.Item>
                            <table><tr><td className="p-5"style={{width:'50%'}} ><img src={Image6} style={{width:'100%'}}/>
            </td><td className="p-5"><div className="text  text-left ">
            <h2 style={{fontSize:"33px",fontWeight:"700"}}>Why Choose us</h2>
            <h4  className="text-primary p-1" style={{textDecoration:"underline",fontSize:"20px",fontWeight:"700",color:"#0cb8b6"}}>BECAUSE WE ARE RELIABLE</h4>
            
            The Feednet Solutions team leverages unrivalled industry experts to design solutions that accelerate innovation while improving project quality and profitability. Our focus on People, Process and Technology are the cornerstone of why our customers choose to do business with us.
								 
            <blockquote className="p-3" style={{borderLeft:"5px solid gray",fontStyle:"italic"}}>
                                
            We always stay with our clients and respect their business. We deliver 100% and provide instant response.
                            
                            </blockquote>
                
                <ul className="text-left">
                                <li className=" p-1"style={{borderBottom:"5px solid lightblue",width : "100%", listStyle:"none"}}><i className="fa fa-check"></i> AI Solutions/Services </li><br/>
                                <li className="p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Product Development</li><br/>
                                <li className=" p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> R&D </li><br/>
                                <li className=" p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Out Sourcing Employees</li><br/>
								<li className=" p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Coworeking Space</li><br/>
								<li className=" p-1"style={{borderBottom:"5px solid lightblue",width:"100%",listStyle:"none"}}><i className="fa fa-check"></i> Web Development</li>
                            </ul></div></td></tr></table>













                            </Carousel.Item>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            </Carousel>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            </div>












                            <div className="p-3"style={{backgroundColor:"whitesmoke"}}>



            <h1 className="text-centre text-dark"style={{fontSize:"33px",fontWeight:"700"}}>OUR PARTNERS</h1>
            <p className="text-primary">_ ___ _</p>
        <table >
            <tr>
                <td style={{padding:"50px"}}>
                    <img src={Image}/> 
                    </td> 
                    <td style={{padding:"50px"}}>
                        <img src={Image1}/> 
                        </td> 
                        <td style={{padding:"50px"}}>
                            <img src={Image2}/>
                              </td> 
                              <td style={{padding:"50px"}}>
                                  <img src={Image3}/> 
                                  </td>
                                  </tr>
                                  </table></div>





        </div>











































































































  
 











           
            
            
            
            
            
            
            
            
            
            
            
          
                           
                           
                            
                            
                            
                            
                            






                                  )
    }
}