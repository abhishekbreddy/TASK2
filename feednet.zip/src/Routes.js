import React from'react'

class Routes extends React.Component{
    render(){
        return(<div><Navigation1/>
      
            <switch>
          
          <Route exact path="/"component={Home}/>
          <Route exact path="/Training"component={Training}/>
          <Route exact path="/Adagency" component={Adagency}/>
          <Route exact path="/Overseas"component={Overseas}/>
          <Route exact path="/Contact"component={Contact}/>
          <Route exact path="/Services"component={Services}/>
          <Route exact path="/Pay" component={Pay}/>
          <Route exact path="/carriers"component={Career}/>
          <Route exact path="/Blog"component={Blog}/>
          <Route exact path="/R&D"component={Reaserch}/>
          <Route exact path="/Product"component={Product}/>
          <Route exact path="/AI"component={AI}/>
          
      
      
      </switch></div>)
    }
}