import logo from './logo.svg';
import {React  } from "react";
import './App.css';
import Footer from './compomemt/Footer'
import Fheader from './compomemt/footerheader'
import 'E:/feednet/feednet/node_modules/bootstrap/dist/css/bootstrap.css'
import {BrowserRouter, BrowserRouter as router, Route} from 'react-router-dom'
import Footerhead from './compomemt/Footerhead';
import Home from './compomemt/Home'
import Training from './compomemt/Training'
import Adagency from './compomemt/Adagency'
import Overseas from './compomemt/Overseas'
import Contact from './compomemt/Contact'
import Services from './compomemt/Services'
import Blog from './compomemt/Blog'
import Pay from './compomemt/Pay'
import Career from './compomemt/Career'
import Navigation from './compomemt/Navigation'
import Navigation1 from './compomemt/Navigation1'
import './bootstrap/dist/css/bootstrap.css'
import './bootstrap-icons/icons/chevron-double-right.svg'
import Reaserch from './compomemt/R&D'
import Product from './compomemt/Product'
import AI from'./compomemt/AI'
import Otherservices from './compomemt/Other';
import corporate from './compomemt/Corporate'
import Internships from'./compomemt/Internships'
import workshops from './compomemt/Workshops'
import Seminars from './compomemt/Seminars'
import Servicepayment from './compomemt/Servicepayment'
import Coursepayment from './compomemt/Coursepayment'
import Workshop from './compomemt/Workshops';
import Jobapply from './compomemt/Jobapply'
import About from './compomemt/About'
import Audit from './compomemt/Audit'
import Ourstory from './compomemt/Ourstory'
import Support from './compomemt/Livesuport'


function App()  {
 
   
  return (
    <div className="App">
      <BrowserRouter>
      <Navigation1/>
      
      <switch>
    
    <Route exact path="/"component={Home}/>
    <Route exact path="/Training"component={() => { window.location = 'http://feednetartificialintelligence.com/'; return null;}} />
    <Route exact path="/Adagency" component={() => { window.location = 'http://feednetadagency.com/'; return null;}}/>
    <Route exact path="/Overseas"component={() => { window.location = 'http://feednetoverseas.com/'; return null;}}/>
    <Route exact path="/Contact"component={Contact}/>
    <Route exact path="/Services"component={Services}/>
    <Route exact path="/Pay" component={Pay}/>
    <Route exact path="/carriers"component={Career}/>
    <Route exact path="/Blog"component={Blog}/>
    <Route exact path="/R&D"component={Reaserch}/>
    <Route exact path="/Product"component={Product}/>
    <Route exact path="/AI"component={AI}/>
    <Route exact path="/Other"component={Otherservices}/>
    <Route exact path="/corporate"component={corporate}/>
    <Route exact path="/Seminars"component={Seminars}/>
    <Route exact path="/Internships"component={Internships}/>
    <Route exact path="/Workshops"component={Workshop}/>
    <Route exact path="/servicepayment"component={Servicepayment}/>
    <Route exact path="/Coursepayment"component={Coursepayment}/>
    <Route exact path="/jobapply"component={Jobapply}/>
    <Route exact path="/About" component={About}/>
    <private Route exact path="/Ourstory" component={Ourstory}/>
    <private Route exact path="/Audit" component={Audit}/>
    <private Route exact path="/suport"component={Support}/>
    <Route exact path="/Location"component={()=>{ window.location = 'https://www.google.com/maps/dir//feednetsolution/@17.4359666,78.3789042,14z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb91fe6992fceb:0x24fcbaa476a49d88!2m2!1d78.3844447!2d17.444752'; return null;}}/>


</switch>
<Footerhead/>
<Footer/>
</BrowserRouter>    
      
    </div>
  );
}

export default App;
