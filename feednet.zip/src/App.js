import logo from './logo.svg';
import {React  } from "react";
import './App.css';
import Footer from './compomemt/Footer'
import Fheader from './compomemt/footerheader'
//import 'E:\feednet\feednet\node_modules\bootstrap\dist\css\bootstrap.css'
import {BrowserRouter, BrowserRouter as router, Route} from 'react-router-dom'
import Footerhead from './compomemt/Footerhead';
import Home from './compomemt/Home'
import Training from './compomemt/Training'
import Adagency from './compomemt/Adagency'
import Overseas from './compomemt/Overseas'
import Contact from './compomemt/Contact'
import Services from './compomemt/Services'
import Blog from './compomemt/Blog'
import Pay from './compomemt/Pay'
import Career from './compomemt/Career'
import Navigation from './compomemt/Navigation'
import Navigation1 from './compomemt/Navigation1'
import './bootstrap/dist/css/bootstrap.css'
import './bootstrap-icons/icons/chevron-double-right.svg'
import Reaserch from './compomemt/R&D'
import Product from './compomemt/Product'
import AI from'./compomemt/AI'


function App()  {
 
   
  return (
    <div className="App">
      <BrowserRouter>
      <Navigation1/>
      
      <switch>
    
    <Route exact path="/"component={Home}/>
    <Route exact path="/Training"component={() => { window.location = 'http://feednetartificialintelligence.com/'; return null;}} />
    <Route exact path="/Adagency" component={() => { window.location = 'http://feednetadagency.com/'; return null;}}/>
    <Route exact path="/Overseas"component={() => { window.location = 'http://feednetoverseas.com/'; return null;}}/>
    <Route exact path="/Contact"component={Contact}/>
    <Route exact path="/Services"component={Services}/>
    <Route exact path="/Pay" component={Pay}/>
    <Route exact path="/carriers"component={Career}/>
    <Route exact path="/Blog"component={Blog}/>
    <Route exact path="/R&D"component={Reaserch}/>
    <Route exact path="/Product"component={Product}/>
    <Route exact path="/AI"component={AI}/>
    


</switch>
<Footerhead/>
<Footer/>
</BrowserRouter>    
      
    </div>
  );
}

export default App;
